package com.cardiokey.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.cardiokey.data.models.HealthScanAnalytics
import com.cardiokey.ui.theme.CardioKeyColors
import kotlin.math.roundToInt

// ── Gradient Button ──────────────────────────────────────────────
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    val gradient = Brush.horizontalGradient(
        colors = if (enabled) listOf(CardioKeyColors.PurpleStart, CardioKeyColors.PurpleEnd)
        else listOf(Color(0xFF444466), Color(0xFF333355))
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(gradient)
            .then(
                if (enabled) Modifier else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        val clickModifier = if (enabled) Modifier else Modifier
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color.Transparent,
            onClick = { if (enabled) onClick() },
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .background(Color.Transparent)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) {
                    Icon(icon, contentDescription = null,
                        tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    color = if (enabled) Color.White else Color(0xFF888899),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

// ── CK Card surface ──────────────────────────────────────────────
@Composable
fun CKCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardioKeyColors.SurfaceNavy)
            .border(1.dp, CardioKeyColors.CardBorder, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

// ── Section Header ───────────────────────────────────────────────
@Composable
fun SectionHeader(title: String, subtitle: String? = null) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = CardioKeyColors.TextPrimary
        )
        if (subtitle != null) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextSecondary
            )
        }
    }
}

// ── Status Badge ─────────────────────────────────────────────────
@Composable
fun StatusBadge(authenticated: Boolean, sessionType: String? = null) {
    val isEnroll = sessionType.equals("enroll", ignoreCase = true)
    val (text, color) = when {
        isEnroll -> "ENROLLMENT BASELINE" to CardioKeyColors.NeonMint
        authenticated -> "ACCESS GRANTED" to CardioKeyColors.NeonMint
        else -> "ACCESS DENIED" to CardioKeyColors.ElectricCoral
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 1.sp
        )
    }
}

// ── Confidence Radial Gauge ───────────────────────────────────────
@Composable
fun ConfidenceGauge(confidence: Double, modifier: Modifier = Modifier) {
    val percentage = (confidence * 100).roundToInt().coerceIn(0, 100)
    val color = when {
        percentage >= 80 -> CardioKeyColors.NeonMint
        percentage >= 60 -> CardioKeyColors.StatusAmber
        else -> CardioKeyColors.ElectricCoral
    }
    Box(
        modifier = modifier.size(100.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            progress = { confidence.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxSize(),
            color = color,
            trackColor = CardioKeyColors.CardBorder,
            strokeWidth = 8.dp
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$percentage%",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = color
            )
            Text(
                text = "Confidence",
                fontSize = 9.sp,
                color = CardioKeyColors.TextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ── Health Metric Chip ────────────────────────────────────────────
@Composable
fun HealthMetricChip(
    label: String,
    value: String,
    unit: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.1f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(text = label, fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = unit, fontSize = 10.sp, color = CardioKeyColors.TextMuted)
        }
    }
}

// ── Health Metrics Grid ───────────────────────────────────────────
@Composable
fun HealthMetricsGrid(health: HealthScanAnalytics?, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        SectionHeader(title = "Health Metrics", subtitle = "From last biometric scan")
        Spacer(Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HealthMetricChip(
                label = "HEART RATE",
                value = health?.heartRateBpm?.let { "%.0f".format(it) } ?: "--",
                unit = "bpm",
                icon = Icons.Default.Favorite,
                color = CardioKeyColors.HeartRateColor,
                modifier = Modifier.weight(1f)
            )
            HealthMetricChip(
                label = "HRV RMSSD",
                value = health?.hrvRmssdMs?.let { "%.1f".format(it) } ?: "--",
                unit = "ms",
                icon = Icons.Default.Timeline,
                color = CardioKeyColors.HrvColor,
                modifier = Modifier.weight(1f)
            )
            HealthMetricChip(
                label = "RESP RATE",
                value = health?.respiratoryRateRpm?.let { "%.1f".format(it) } ?: "--",
                unit = "rpm",
                icon = Icons.Default.Air,
                color = CardioKeyColors.RespiratoryColor,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HealthMetricChip(
                label = "SpO2",
                value = health?.spo2Percent?.let { "%.1f".format(it) } ?: "--",
                unit = "%",
                icon = Icons.Default.Bloodtype,
                color = CardioKeyColors.SpO2Color,
                modifier = Modifier.weight(1f)
            )
            HealthMetricChip(
                label = "STRESS",
                value = health?.stressLevel ?: "--",
                unit = "level",
                icon = Icons.Default.Psychology,
                color = CardioKeyColors.StressColor,
                modifier = Modifier.weight(1f)
            )
            HealthMetricChip(
                label = "AFib RISK",
                value = health?.afibRisk ?: "--",
                unit = "risk",
                icon = Icons.Default.MonitorHeart,
                color = CardioKeyColors.AfibColor,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// ── Loading Indicator ─────────────────────────────────────────────
@Composable
fun CKLoadingRow(label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = CardioKeyColors.NeonMint
        )
        Spacer(Modifier.width(10.dp))
        Text(label, style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
    }
}

// ── Error and Success Text ────────────────────────────────────────
@Composable
fun CKErrorText(message: String) {
    Text(message, color = CardioKeyColors.ElectricCoral, style = MaterialTheme.typography.bodySmall)
}

@Composable
fun CKSuccessText(message: String) {
    Text(message, color = CardioKeyColors.NeonMint, style = MaterialTheme.typography.bodySmall)
}

// ── PIN Entry Dialog ──────────────────────────────────────────────
@Composable
fun PinEntryDialog(
    onPinConfirmed: (String) -> Unit,
    onDismiss: () -> Unit,
    error: String? = null
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardioKeyColors.SurfaceNavy,
        title = {
            Text("Admin Portal", color = CardioKeyColors.TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    "Enter your 6-digit admin PIN to continue.",
                    color = CardioKeyColors.TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("6-Digit PIN") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CardioKeyColors.PurpleStart,
                        unfocusedBorderColor = CardioKeyColors.CardBorder,
                        focusedTextColor = CardioKeyColors.TextPrimary,
                        unfocusedTextColor = CardioKeyColors.TextPrimary,
                        cursorColor = CardioKeyColors.PurpleStart
                    )
                )
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    CKErrorText(error)
                }
            }
        },
        confirmButton = {
            GradientButton(
                text = "Enter Admin Portal",
                onClick = { onPinConfirmed(pin) },
                enabled = pin.length == 6
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = CardioKeyColors.TextSecondary)
            }
        }
    )
}

// ── Auth Result Summary Card ──────────────────────────────────────
@Composable
fun AuthResultSummaryCard(
    sessionResponse: com.cardiokey.data.models.AuthSessionResponse,
    modifier: Modifier = Modifier
) {
    CKCard(modifier = modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                StatusBadge(authenticated = sessionResponse.authenticated)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = sessionResponse.predictedUser ?: "Unknown",
                    style = MaterialTheme.typography.titleMedium,
                    color = CardioKeyColors.TextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Margin: ${"%.3f".format(sessionResponse.margin)} | Threshold: ${"%.3f".format(sessionResponse.threshold)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
            }
            ConfidenceGauge(confidence = sessionResponse.similarity)
        }
    }
}

// ── CK Custom Text Field ──────────────────────────────────────────
@Composable
fun CKTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isPassword: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CardioKeyColors.PurpleStart,
            unfocusedBorderColor = CardioKeyColors.CardBorder,
            focusedLabelColor = CardioKeyColors.PurpleStart,
            unfocusedLabelColor = CardioKeyColors.TextMuted,
            focusedTextColor = CardioKeyColors.TextPrimary,
            unfocusedTextColor = CardioKeyColors.TextPrimary,
            cursorColor = CardioKeyColors.PurpleStart,
            focusedContainerColor = CardioKeyColors.InputBackground,
            unfocusedContainerColor = CardioKeyColors.InputBackground
        )
    )
}
