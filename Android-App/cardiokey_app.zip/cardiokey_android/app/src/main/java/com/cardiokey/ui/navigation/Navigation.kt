package com.cardiokey.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.navigation

object NavRoutes {
    // Root
    const val ROLE_SELECTION = "role_selection"

    // Admin
    const val ADMIN_ROOT = "admin"
    const val ADMIN_SETUP = "admin/setup"
    const val ADMIN_DASHBOARD = "admin/dashboard"
    const val ADMIN_USER_MANAGEMENT = "admin/users"
    const val ADMIN_ENROLLMENT = "admin/enrollment"
    const val ADMIN_AUTHENTICATE = "admin/authenticate"

    // Customer
    const val CUSTOMER_ROOT = "customer"
    const val CUSTOMER_DASHBOARD = "customer/dashboard"
    const val CUSTOMER_HISTORY = "customer/history"
    const val CUSTOMER_PROFILE = "customer/profile"
}

sealed class AdminDest(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    data object Setup : AdminDest(NavRoutes.ADMIN_SETUP, "Setup", Icons.Default.Wifi)
    data object Dashboard : AdminDest(NavRoutes.ADMIN_DASHBOARD, "Dashboard", Icons.Default.Dashboard)
    data object Users : AdminDest(NavRoutes.ADMIN_USER_MANAGEMENT, "Users", Icons.Default.People)
    data object Enroll : AdminDest(NavRoutes.ADMIN_ENROLLMENT, "Enroll", Icons.Default.PersonAdd)
    data object Authenticate : AdminDest(NavRoutes.ADMIN_AUTHENTICATE, "Scan", Icons.Default.Fingerprint)
}

val adminDestinations = listOf(
    AdminDest.Setup,
    AdminDest.Dashboard,
    AdminDest.Users,
    AdminDest.Enroll,
    AdminDest.Authenticate
)

sealed class CustomerDest(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    data object Dashboard : CustomerDest(NavRoutes.CUSTOMER_DASHBOARD, "Dashboard", Icons.Default.Home)
    data object History : CustomerDest(NavRoutes.CUSTOMER_HISTORY, "History", Icons.Default.History)
    data object Profile : CustomerDest(NavRoutes.CUSTOMER_PROFILE, "Profile", Icons.Default.Person)
}

val customerDestinations = listOf(
    CustomerDest.Dashboard,
    CustomerDest.History,
    CustomerDest.Profile
)
