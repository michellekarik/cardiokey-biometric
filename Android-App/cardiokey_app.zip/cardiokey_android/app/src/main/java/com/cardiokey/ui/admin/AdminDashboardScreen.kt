package com.cardiokey.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AdminSystemStats
import com.cardiokey.ui.components.CKCard
import com.cardiokey.ui.components.CKErrorText
import com.cardiokey.ui.components.CKLoadingRow
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.AdminDashboardViewModel

@Composable
fun AdminDashboardScreen(viewModel: AdminDashboardViewModel) {
    val stats by viewModel.stats.collectAsState()
    val users by viewModel.users.collectAsState()
    val userHistories by viewModel.userHistories.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.refresh()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "System Analytics",
                        style = MaterialTheme.typography.headlineSmall,
                        color = CardioKeyColors.TextPrimary
                    )
                    Text(
                        text = "Real-time biometric performance & telemetry",
                        style = MaterialTheme.typography.bodySmall,
                        color = CardioKeyColors.TextSecondary
                    )
                }
                IconButton(onClick = { viewModel.refresh() }) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = CardioKeyColors.NeonMint,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = CardioKeyColors.TextSecondary
                        )
                    }
                }
            }
        }

        // Error message if any
        if (error != null) {
            item {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    CKErrorText("Analytics sync notice: ${error ?: "Using local cache"}")
                }
            }
        }

        // Stat Cards Grid
        item {
            StatsSection(stats = stats)
        }

        // Section Title: Expandable User Health Telemetry
        item {
            Column {
                Text(
                    text = "User Directory & Health Telemetry",
                    style = MaterialTheme.typography.titleMedium,
                    color = CardioKeyColors.TextPrimary
                )
                Text(
                    text = "Tap any user card to inspect their complete live health trends, authentication verdicts, and match confidence.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
            }
        }

        if (users.isEmpty() && !isLoading) {
            item {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "No users enrolled yet. Onboard users in the User Management tab.",
                        color = CardioKeyColors.TextMuted,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Expandable User Cards in Admin Dashboard
        items(users, key = { it.userId }) { user ->
            ExpandableUserCard(
                user = user,
                history = userHistories[user.userId],
                onExpand = { viewModel.loadUserHistory(user.userId) }
            )
        }
    }
}

@Composable
private fun StatsSection(stats: AdminSystemStats?) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "REGISTERED USERS",
                value = stats?.totalRegisteredUsers?.toString() ?: "0",
                icon = Icons.Default.People,
                color = CardioKeyColors.PurpleStart,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "VERIFIED USERS",
                value = stats?.verifiedUsersCount?.toString() ?: "0",
                icon = Icons.Default.VerifiedUser,
                color = CardioKeyColors.NeonMint,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "AUTH ATTEMPTS",
                value = stats?.totalAuthAttempts?.toString() ?: "0",
                icon = Icons.Default.Fingerprint,
                color = CardioKeyColors.RespiratoryColor,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "SYSTEM ACCURACY",
                value = stats?.systemAccuracyRate?.let { "%.1f%%".format(it * 100) } ?: "--",
                icon = Icons.Default.Analytics,
                color = CardioKeyColors.NeonMint,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "AVG CONFIDENCE MARGIN",
                value = stats?.averageMargin?.let { "%.3f".format(it) } ?: "--",
                icon = Icons.Default.Speed,
                color = CardioKeyColors.SpO2Color,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(CardioKeyColors.SurfaceNavy)
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = CardioKeyColors.TextSecondary,
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}
