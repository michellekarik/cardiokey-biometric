package com.cardiokey.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.ui.components.CKCard
import com.cardiokey.ui.components.GradientButton
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.CustomerVerifyState
import com.cardiokey.viewmodel.CustomerViewModel

@Composable
fun CustomerProfileScreen(
    customerViewModel: CustomerViewModel,
    onSignOut: () -> Unit
) {
    val verifyState by customerViewModel.verifyState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))

        // Avatar
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(CardioKeyColors.PurpleStart, CardioKeyColors.PurpleEnd)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(Modifier.height(16.dp))

        when (val state = verifyState) {
            is CustomerVerifyState.Verified -> {
                val profile = state.profile
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${profile.firstName} ${profile.lastName}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = CardioKeyColors.TextPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = "Verified Identity",
                        tint = CardioKeyColors.NeonMint,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = profile.email,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CardioKeyColors.TextSecondary
                )

                Spacer(Modifier.height(24.dp))

                // Profile Details Card
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "ACCOUNT DETAILS",
                        style = MaterialTheme.typography.labelSmall,
                        color = CardioKeyColors.TextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    ProfileDetailRow(label = "User ID", value = profile.userId)
                    HorizontalDivider(color = CardioKeyColors.DividerLine, modifier = Modifier.padding(vertical = 8.dp))
                    ProfileDetailRow(label = "Age", value = "${profile.age} years old")
                    HorizontalDivider(color = CardioKeyColors.DividerLine, modifier = Modifier.padding(vertical = 8.dp))
                    ProfileDetailRow(label = "Biological Sex", value = profile.sex)
                    HorizontalDivider(color = CardioKeyColors.DividerLine, modifier = Modifier.padding(vertical = 8.dp))
                    ProfileDetailRow(label = "Biometric Role", value = profile.role)
                    HorizontalDivider(color = CardioKeyColors.DividerLine, modifier = Modifier.padding(vertical = 8.dp))
                    ProfileDetailRow(label = "Verification Status", value = "Verified (Email Confirmed)")
                }

                Spacer(Modifier.height(16.dp))

                // Security & Privacy Card
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = null,
                            tint = CardioKeyColors.NeonMint,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "CardioKey Data Privacy",
                            fontWeight = FontWeight.SemiBold,
                            color = CardioKeyColors.TextPrimary
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Your ECG + PPG biometric records are encrypted on Supabase PostgreSQL and processed securely via AWS EC2. Under our strict RBAC policy, you can only query scans matching your verified Google email identity.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CardioKeyColors.TextSecondary
                    )
                }
            }

            else -> {
                Text(
                    text = "Customer Account",
                    style = MaterialTheme.typography.headlineSmall,
                    color = CardioKeyColors.TextPrimary
                )
            }
        }

        Spacer(Modifier.height(32.dp))

        // Sign Out Button
        Button(
            onClick = onSignOut,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CardioKeyColors.ElectricCoral.copy(alpha = 0.2f),
                contentColor = CardioKeyColors.ElectricCoral
            )
        ) {
            Icon(
                Icons.Default.ExitToApp,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text("Sign Out", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ProfileDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = CardioKeyColors.TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = CardioKeyColors.TextPrimary
        )
    }
}
