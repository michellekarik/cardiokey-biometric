package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.WifiConfigureRequest
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class WifiSetupState {
    object NotOnSetupNetwork : WifiSetupState()
    object CheckingSetupAp : WifiSetupState()
    object ReadyToConfigure : WifiSetupState()
    object Submitting : WifiSetupState()
    object CredentialsAccepted : WifiSetupState()
    data class Failed(val message: String) : WifiSetupState()
}

sealed class DeviceLinkState {
    object Unlinked : DeviceLinkState()
    object Checking : DeviceLinkState()
    object Linked : DeviceLinkState()
    data class Failed(val message: String) : DeviceLinkState()
}

class SetupViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private val setupApi by lazy { NetworkModule.setupApi() }

    private val _wifiState = MutableStateFlow<WifiSetupState>(WifiSetupState.NotOnSetupNetwork)
    val wifiState: StateFlow<WifiSetupState> = _wifiState.asStateFlow()

    private val _linkState = MutableStateFlow<DeviceLinkState>(DeviceLinkState.Unlinked)
    val linkState: StateFlow<DeviceLinkState> = _linkState.asStateFlow()

    fun checkSetupAp() {
        viewModelScope.launch {
            _wifiState.value = WifiSetupState.CheckingSetupAp
            runCatching { setupApi.getStatus() }
                .onSuccess { 
                    _wifiState.value = WifiSetupState.ReadyToConfigure 
                }
                .onFailure { e ->
                    val detail = e.localizedMessage ?: "Connection error"
                    _wifiState.value = WifiSetupState.Failed(
                        "Cannot reach 192.168.4.1 ($detail).\n\n" +
                        "1. Turn OFF Mobile Data.\n" +
                        "2. In Android Wi-Fi settings, tap CARDIOKEY-ESP32 and choose 'Stay connected' when warned of no internet."
                    )
                }
        }
    }

    fun submitWifiCredentials(ssid: String, password: String) {
        viewModelScope.launch {
            _wifiState.value = WifiSetupState.Submitting
            runCatching {
                setupApi.configureWifi(WifiConfigureRequest(ssid, password))
            }.onSuccess { response ->
                val isOk = response.accepted || response.success || response.connected
                if (isOk) {
                    _wifiState.value = WifiSetupState.CredentialsAccepted
                } else {
                    _wifiState.value = WifiSetupState.Failed(response.message.ifBlank { "Device rejected credentials." })
                }
            }.onFailure {
                _wifiState.value = WifiSetupState.Failed(it.message ?: "Unknown error during Wi-Fi setup.")
            }
        }
    }

    fun linkDeviceOnLan(deviceIp: String) {
        viewModelScope.launch {
            _linkState.value = DeviceLinkState.Checking
            runCatching { NetworkModule.deviceApi(deviceIp).getStatus() }
                .onSuccess {
                    prefs.setDeviceIp(deviceIp)
                    _linkState.value = DeviceLinkState.Linked
                }
                .onFailure {
                    _linkState.value = DeviceLinkState.Failed("Cannot reach $deviceIp. Make sure you're on home Wi-Fi and the IP is correct.")
                }
        }
    }

    fun saveDeviceIp(ip: String) {
        viewModelScope.launch { prefs.setDeviceIp(ip) }
    }

    fun saveBackendUrl(url: String) {
        viewModelScope.launch {
            val parsed = android.net.Uri.parse(url.trim())
            val base = parsed.buildUpon()
                .encodedPath("/")
                .clearQuery()
                .fragment(null)
                .build()
                .toString()
                .let { if (it.endsWith("/")) it else "$it/" }
            prefs.setBackendUrl(base)
        }
    }
}
