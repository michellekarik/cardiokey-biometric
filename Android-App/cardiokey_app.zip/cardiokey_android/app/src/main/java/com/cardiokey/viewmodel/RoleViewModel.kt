package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.AppRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest

// Hardcoded default PIN hash for "123456" — Admin should change via Settings in production
private const val DEFAULT_PIN = "123456"

class RoleViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)

    private val _role = MutableStateFlow<AppRole>(AppRole.None)
    val role: StateFlow<AppRole> = _role.asStateFlow()

    private val _pinError = MutableStateFlow<String?>(null)
    val pinError: StateFlow<String?> = _pinError.asStateFlow()

    fun verifyAdminPin(enteredPin: String) {
        val hashedInput = sha256(enteredPin)
        viewModelScope.launch {
            // If no pin hash stored yet, bootstrap with DEFAULT_PIN
            prefs.adminPinHash.collect { storedHash ->
                val expected = storedHash ?: sha256(DEFAULT_PIN)
                if (storedHash == null) {
                    prefs.setAdminPinHash(sha256(DEFAULT_PIN))
                }
                if (hashedInput == expected) {
                    _pinError.value = null
                    _role.value = AppRole.Admin
                } else {
                    _pinError.value = "Incorrect PIN. Please try again."
                }
                return@collect
            }
        }
    }

    fun setCustomerRole(email: String, idToken: String) {
        viewModelScope.launch {
            prefs.setCustomerSession(email, idToken)
            _role.value = AppRole.Customer(email, idToken)
        }
    }

    fun signOut() {
        viewModelScope.launch {
            prefs.clearCustomerSession()
            _role.value = AppRole.None
        }
    }

    fun exitAdmin() {
        _role.value = AppRole.None
    }

    fun clearPinError() {
        _pinError.value = null
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
