package com.cardiokey.data.repository

import com.cardiokey.data.models.*
import com.cardiokey.network.FlaskApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FlaskRepository(private val api: FlaskApiService) {

    suspend fun createUser(request: CreateUserRequest): Result<UserProfile> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.createUser(request)
            if (response.isSuccessful) response.body()!!
            else error("Server error ${response.code()}: ${response.errorBody()?.string()}")
        }
    }

    suspend fun getAllUsers(): Result<List<UserProfile>> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.getAllUsers()
            if (response.isSuccessful) response.body() ?: emptyList()
            else error("Server error ${response.code()}: ${response.errorBody()?.string()}")
        }
    }

    suspend fun getUserHistory(userId: String): Result<List<AuthSessionResponse>> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.getUserFullHistory(userId)
            if (response.isSuccessful) response.body() ?: emptyList()
            else error("Server error ${response.code()}")
        }
    }

    suspend fun verifyEmailMatch(email: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.verifyEmailMatch(email)
            if (response.isSuccessful) response.body()!!
            else error("Email not registered or not verified (${response.code()})")
        }
    }

    suspend fun startEnrollment(userId: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.startEnrollment(mapOf("user_id" to userId))
            if (response.isSuccessful) response.body()?.get("session_id") ?: error("No session_id returned")
            else error("Start enrollment failed (${response.code()})")
        }
    }

    suspend fun startAuthScan(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.startAuthScan(emptyMap())
            if (response.isSuccessful) response.body()?.get("session_id") ?: error("No session_id returned")
            else error("Start auth scan failed (${response.code()})")
        }
    }

    suspend fun getSessionStatus(sessionId: String): Result<AuthSessionResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.getSessionStatus(sessionId)
            if (response.isSuccessful) response.body()!!
            else error("Session status error (${response.code()}): ${response.errorBody()?.string()}")
        }
    }

    suspend fun verifyGroundTruth(sessionId: String, actualUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.verifyGroundTruth(GroundTruthValidationRequest(sessionId, actualUserId))
            if (!response.isSuccessful) error("Ground truth error (${response.code()})")
        }
    }


    suspend fun reportDeviceStatus(sessionId: String, status: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val response = api.reportDeviceStatus(sessionId, mapOf("status" to status))
                if (!response.isSuccessful) {
                    error("Could not update session in Supabase (${response.code()}): ${response.errorBody()?.string()}")
                }
            }
        }

    suspend fun getAdminStats(): Result<AdminSystemStats> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.getAdminStats()
            if (response.isSuccessful) response.body()!!
            else error("Stats error (${response.code()})")
        }
    }

    suspend fun getCustomerHistory(idToken: String): Result<List<AuthSessionResponse>> = withContext(Dispatchers.IO) {
        runCatching {
            val response = api.getCustomerPersonalHistory("Bearer $idToken")
            if (response.isSuccessful) response.body() ?: emptyList()
            else error("Customer history error (${response.code()})")
        }
    }
}
