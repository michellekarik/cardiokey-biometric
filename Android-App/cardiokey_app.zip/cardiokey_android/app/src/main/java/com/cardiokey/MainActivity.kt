package com.cardiokey

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.cardiokey.data.models.AppRole
import com.cardiokey.ui.admin.*
import com.cardiokey.ui.auth.RoleSelectionScreen
import com.cardiokey.ui.customer.CustomerDashboardScreen
import com.cardiokey.ui.customer.CustomerHistoryScreen
import com.cardiokey.ui.customer.CustomerProfileScreen
import com.cardiokey.ui.navigation.AdminDest
import com.cardiokey.ui.navigation.CustomerDest
import com.cardiokey.ui.navigation.NavRoutes
import com.cardiokey.ui.navigation.adminDestinations
import com.cardiokey.ui.navigation.customerDestinations
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.ui.theme.CardioKeyTheme
import com.cardiokey.viewmodel.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CardioKeyTheme {
                CardioKeyApp()
            }
        }
    }
}

@Composable
fun CardioKeyApp() {
    val roleViewModel: RoleViewModel = viewModel()
    val role by roleViewModel.role.collectAsState()

    AnimatedContent(
        targetState = role,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "workspace_transition"
    ) { currentRole ->
        when (currentRole) {
            is AppRole.None -> {
                RoleSelectionScreen(
                    roleViewModel = roleViewModel,
                    onAdminAuthenticated = { /* Role state updates automatically */ },
                    onCustomerAuthenticated = { /* Role state updates automatically */ }
                )
            }
            is AppRole.Admin -> {
                AdminWorkspace(onExit = { roleViewModel.exitAdmin() })
            }
            is AppRole.Customer -> {
                CustomerWorkspace(
                    email = currentRole.email,
                    idToken = currentRole.idToken,
                    onSignOut = { roleViewModel.signOut() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminWorkspace(onExit: () -> Unit) {
    val navController = rememberNavController()
    val setupVm: SetupViewModel = viewModel()
    val userVm: UserManagementViewModel = viewModel()
    val enrollVm: EnrollViewModel = viewModel()
    val authVm: AuthViewModel = viewModel()
    val dashboardVm: AdminDashboardViewModel = viewModel()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "CardioKey",
                            fontWeight = FontWeight.Bold,
                            color = CardioKeyColors.TextPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "ADMIN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = CardioKeyColors.PurpleStart,
                            modifier = Modifier
                                .background(
                                    CardioKeyColors.PurpleStart.copy(alpha = 0.2f),
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                },
                actions = {
                    TextButton(onClick = onExit) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Exit Admin",
                            tint = CardioKeyColors.TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Exit", color = CardioKeyColors.TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardioKeyColors.BackgroundInk
                )
            )
        },
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            NavigationBar(
                containerColor = CardioKeyColors.SurfaceNavy
            ) {
                adminDestinations.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                dest.icon,
                                contentDescription = dest.label,
                                tint = if (selected) CardioKeyColors.PurpleStart else CardioKeyColors.TextSecondary
                            )
                        },
                        label = {
                            Text(
                                dest.label,
                                color = if (selected) CardioKeyColors.TextPrimary else CardioKeyColors.TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CardioKeyColors.PurpleStart.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.ADMIN_DASHBOARD,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NavRoutes.ADMIN_SETUP) {
                AdminSetupScreen(viewModel = setupVm)
            }
            composable(NavRoutes.ADMIN_DASHBOARD) {
                AdminDashboardScreen(viewModel = dashboardVm)
            }
            composable(NavRoutes.ADMIN_USER_MANAGEMENT) {
                UserManagementScreen(viewModel = userVm)
            }
            composable(NavRoutes.ADMIN_ENROLLMENT) {
                EnrollmentScreen(enrollVm = enrollVm, authVm = authVm, userVm = userVm)
            }
            composable(NavRoutes.ADMIN_AUTHENTICATE) {
                AuthenticateScreen(authVm = authVm, userVm = userVm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerWorkspace(
    email: String,
    idToken: String,
    onSignOut: () -> Unit
) {
    val navController = rememberNavController()
    val customerVm: CustomerViewModel = viewModel()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "CardioKey",
                            fontWeight = FontWeight.Bold,
                            color = CardioKeyColors.TextPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "HEALTH",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = CardioKeyColors.NeonMint,
                            modifier = Modifier
                                .background(
                                    CardioKeyColors.NeonMint.copy(alpha = 0.15f),
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onSignOut) {
                        Icon(
                            Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = CardioKeyColors.ElectricCoral
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CardioKeyColors.BackgroundInk
                )
            )
        },
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            NavigationBar(
                containerColor = CardioKeyColors.SurfaceNavy
            ) {
                customerDestinations.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                dest.icon,
                                contentDescription = dest.label,
                                tint = if (selected) CardioKeyColors.NeonMint else CardioKeyColors.TextSecondary
                            )
                        },
                        label = {
                            Text(
                                dest.label,
                                color = if (selected) CardioKeyColors.TextPrimary else CardioKeyColors.TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CardioKeyColors.NeonMint.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavRoutes.CUSTOMER_DASHBOARD,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NavRoutes.CUSTOMER_DASHBOARD) {
                CustomerDashboardScreen(
                    customerViewModel = customerVm,
                    userEmail = email,
                    idToken = idToken,
                    onSignOut = onSignOut
                )
            }
            composable(NavRoutes.CUSTOMER_HISTORY) {
                CustomerHistoryScreen(
                    customerViewModel = customerVm,
                    idToken = idToken
                )
            }
            composable(NavRoutes.CUSTOMER_PROFILE) {
                CustomerProfileScreen(
                    customerViewModel = customerVm,
                    onSignOut = onSignOut
                )
            }
        }
    }
}
