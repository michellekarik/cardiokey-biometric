package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.*
import com.cardiokey.data.repository.FlaskRepository
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class CustomerVerifyState {
    object Idle : CustomerVerifyState()
    object Verifying : CustomerVerifyState()
    data class Verified(val profile: UserProfile) : CustomerVerifyState()
    data class NotVerified(val reason: String) : CustomerVerifyState()
}

class CustomerViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private var repo: FlaskRepository? = null

    private val _verifyState = MutableStateFlow<CustomerVerifyState>(CustomerVerifyState.Idle)
    val verifyState: StateFlow<CustomerVerifyState> = _verifyState.asStateFlow()

    private val _history = MutableStateFlow<List<AuthSessionResponse>>(emptyList())
    val history: StateFlow<List<AuthSessionResponse>> = _history.asStateFlow()

    private val _isLoadingHistory = MutableStateFlow(false)
    val isLoadingHistory: StateFlow<Boolean> = _isLoadingHistory.asStateFlow()

    private suspend fun getRepo(): FlaskRepository {
        return repo ?: run {
            val url = prefs.backendUrl.first()?.takeIf { it.isNotBlank() } ?: "https://your-backend-url.example.com/"
            FlaskRepository(NetworkModule.flaskApi(url)).also { repo = it }
        }
    }

    /** Verifies the logged-in Google email against the backend and loads data.
     *  STRICT DATA PRIVACY: Only loads data for the verified email. */
    fun verifyAndLoad(email: String, idToken: String) {
        viewModelScope.launch {
            _verifyState.value = CustomerVerifyState.Verifying
            getRepo().verifyEmailMatch(email)
                .onSuccess { profile ->
                    if (!profile.isVerified) {
                        _verifyState.value = CustomerVerifyState.NotVerified(
                            "Your email is not yet verified. Please check your inbox for a verification link."
                        )
                    } else {
                        _verifyState.value = CustomerVerifyState.Verified(profile)
                        loadHistory(idToken)
                    }
                }
                .onFailure { e ->
                    _verifyState.value = CustomerVerifyState.NotVerified(
                        e.message ?: "Could not verify this account against the registered user directory."
                    )
                }
        }
    }

    private fun loadHistory(idToken: String) {
        viewModelScope.launch {
            _isLoadingHistory.value = true
            getRepo().getCustomerHistory(idToken)
                .onSuccess { _history.value = it.sortedByDescending { s -> s.timestamp } }
                .onFailure {
                    _history.value = emptyList()
                }
            _isLoadingHistory.value = false
        }
    }

    fun refreshHistory(idToken: String) {
        loadHistory(idToken)
    }
}
