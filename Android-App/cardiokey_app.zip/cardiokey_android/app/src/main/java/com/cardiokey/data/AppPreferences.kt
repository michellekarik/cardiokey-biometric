package com.cardiokey.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cardiokey_prefs")

class AppPreferences(context: Context) {

    private val store = context.dataStore

    companion object {
        val KEY_DEVICE_IP = stringPreferencesKey("device_ip")
        val KEY_BACKEND_URL = stringPreferencesKey("backend_url")
        val KEY_ADMIN_PIN_HASH = stringPreferencesKey("admin_pin_hash")
        val KEY_CUSTOMER_EMAIL = stringPreferencesKey("customer_email")
        val KEY_CUSTOMER_TOKEN = stringPreferencesKey("customer_id_token")
    }

    val deviceIp: Flow<String?> = store.data.map { it[KEY_DEVICE_IP] }
    val backendUrl: Flow<String?> = store.data.map { it[KEY_BACKEND_URL] }
    val adminPinHash: Flow<String?> = store.data.map { it[KEY_ADMIN_PIN_HASH] }
    val customerEmail: Flow<String?> = store.data.map { it[KEY_CUSTOMER_EMAIL] }
    val customerToken: Flow<String?> = store.data.map { it[KEY_CUSTOMER_TOKEN] }

    suspend fun setDeviceIp(ip: String) = store.edit { it[KEY_DEVICE_IP] = ip }
    suspend fun setBackendUrl(url: String) = store.edit { it[KEY_BACKEND_URL] = url }
    suspend fun setAdminPinHash(hash: String) = store.edit { it[KEY_ADMIN_PIN_HASH] = hash }
    suspend fun setCustomerSession(email: String, token: String) = store.edit {
        it[KEY_CUSTOMER_EMAIL] = email
        it[KEY_CUSTOMER_TOKEN] = token
    }
    suspend fun clearCustomerSession() = store.edit { preferences ->
        preferences.remove(KEY_CUSTOMER_EMAIL)
        preferences.remove(KEY_CUSTOMER_TOKEN)
    }
}
