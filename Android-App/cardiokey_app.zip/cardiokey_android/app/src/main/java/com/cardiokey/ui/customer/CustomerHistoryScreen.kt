package com.cardiokey.ui.customer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.ui.components.*
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.CustomerViewModel

@Composable
fun CustomerHistoryScreen(
    customerViewModel: CustomerViewModel,
    idToken: String
) {
    val history by customerViewModel.history.collectAsState()
    val isLoadingHistory by customerViewModel.isLoadingHistory.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Scan History",
                        style = MaterialTheme.typography.headlineSmall,
                        color = CardioKeyColors.TextPrimary
                    )
                    Text(
                        text = "Personal chronological authentication & vitals log",
                        style = MaterialTheme.typography.bodySmall,
                        color = CardioKeyColors.TextSecondary
                    )
                }
                IconButton(onClick = { customerViewModel.refreshHistory(idToken) }) {
                    if (isLoadingHistory) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = CardioKeyColors.NeonMint,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh",
                            tint = CardioKeyColors.TextSecondary
                        )
                    }
                }
            }
        }

        if (history.isEmpty() && !isLoadingHistory) {
            item {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "No history available. All future 1:N biometric scans matching your identity will be logged here.",
                        color = CardioKeyColors.TextMuted,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        items(history, key = { it.sessionId }) { session ->
            PersonalHistoryItemCard(session = session)
        }
    }
}

@Composable
private fun PersonalHistoryItemCard(session: AuthSessionResponse) {
    var expanded by remember { mutableStateOf(false) }

    CKCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .animateContentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val isEnroll = session.sessionType.equals("enroll", ignoreCase = true)
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(authenticated = session.authenticated, sessionType = session.sessionType)
                    Spacer(Modifier.width(8.dp))
                    if (!isEnroll) {
                        Text(
                            text = "${(session.similarity * 100).toInt()}% Match",
                            color = if (session.authenticated) CardioKeyColors.NeonMint else CardioKeyColors.ElectricCoral,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = session.timestamp.ifBlank { "Session: ${session.sessionId.take(8)}…" },
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = CardioKeyColors.TextSecondary
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                HorizontalDivider(color = CardioKeyColors.DividerLine)
                Spacer(Modifier.height(12.dp))

                Text(
                    text = "BIOMETRIC DETAILS",
                    style = MaterialTheme.typography.labelSmall,
                    color = CardioKeyColors.TextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Margin: ${"%.3f".format(session.margin)} | Threshold: ${"%.3f".format(session.threshold)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary
                )
                Text(
                    text = "2nd Best Candidate Similarity: ${"%.3f".format(session.secondBestSimilarity)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )

                Spacer(Modifier.height(12.dp))

                // Associated Health Metrics
                session.healthScan?.let { health ->
                    HealthMetricsGrid(health = health, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
