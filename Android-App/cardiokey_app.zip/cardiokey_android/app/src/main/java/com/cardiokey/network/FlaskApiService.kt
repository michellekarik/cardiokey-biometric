package com.cardiokey.network

import com.cardiokey.data.models.AdminSystemStats
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.CreateUserRequest
import com.cardiokey.data.models.GroundTruthValidationRequest
import com.cardiokey.data.models.UserProfile
import retrofit2.Response
import retrofit2.http.*

interface FlaskApiService {
    @POST("api/v1/users/create")
    suspend fun createUser(@Body request: CreateUserRequest): Response<UserProfile>

    @GET("api/v1/users/list")
    suspend fun getAllUsers(): Response<List<UserProfile>>

    @GET("api/v1/users/{userId}/history")
    suspend fun getUserFullHistory(
        @Path("userId") userId: String
    ): Response<List<AuthSessionResponse>>

    @GET("api/v1/users/verify-email-match")
    suspend fun verifyEmailMatch(
        @Query("email") email: String
    ): Response<UserProfile>

    @POST("api/v1/sessions/enroll/start")
    suspend fun startEnrollment(
        @Body body: Map<String, String>
    ): Response<Map<String, String>>

    @POST("api/v1/sessions/auth/start")
    suspend fun startAuthScan(
        @Body body: Map<String, String>
    ): Response<Map<String, String>>

    @GET("api/v1/sessions/{sessionId}/status")
    suspend fun getSessionStatus(
        @Path("sessionId") sessionId: String
    ): Response<AuthSessionResponse>

    @POST("api/v1/sessions/verify-ground-truth")
    suspend fun verifyGroundTruth(
        @Body request: GroundTruthValidationRequest
    ): Response<Map<String, String>>


    @POST("api/v1/sessions/{sessionId}/device-status")
    suspend fun reportDeviceStatus(
        @Path("sessionId") sessionId: String,
        @Body body: Map<String, String>
    ): Response<Map<String, String>>

    @GET("api/v1/admin/stats")
    suspend fun getAdminStats(): Response<AdminSystemStats>

    @GET("api/v1/user/scans/history")
    suspend fun getCustomerPersonalHistory(
        @Header("Authorization") bearerToken: String
    ): Response<List<AuthSessionResponse>>
}
