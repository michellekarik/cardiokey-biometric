package com.cardiokey.data.repository

import android.content.Context
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.SessionStartResponse
import com.cardiokey.data.models.SessionStatusResponse
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.flow.first

/** Recording commands go directly to the ESP32 on the home LAN. */
class DeviceRepository(context: Context) {
    private val prefs = AppPreferences(context.applicationContext)

    private suspend fun api() = NetworkModule.deviceApi(
        prefs.deviceIp.first()?.trim()?.removePrefix("http://")?.removePrefix("https://")
            ?.trimEnd('/')?.takeIf { !it.isNullOrBlank() }
            ?: throw IllegalStateException("ESP32 IP is not configured. Complete Device Setup first.")
    )

    suspend fun startEnrollment(userId: String): SessionStartResponse {
        require(userId.isNotBlank()) { "Select a registered user before starting enrollment." }
        return api().startEnroll(mapOf("user_id" to userId))
    }

    suspend fun startAuthentication(userId: String? = null): SessionStartResponse =
        api().startAuth(if (userId.isNullOrBlank()) emptyMap() else mapOf("user_id" to userId))

    suspend fun getSessionStatus(sessionId: String): SessionStatusResponse =
        api().sessionStatus(sessionId)
}
