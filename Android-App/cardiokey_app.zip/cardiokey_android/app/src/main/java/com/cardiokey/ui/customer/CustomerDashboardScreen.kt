package com.cardiokey.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.UserProfile
import com.cardiokey.ui.components.*
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.CustomerVerifyState
import com.cardiokey.viewmodel.CustomerViewModel

@Composable
fun CustomerDashboardScreen(
    customerViewModel: CustomerViewModel,
    userEmail: String,
    idToken: String,
    onSignOut: () -> Unit
) {
    val verifyState by customerViewModel.verifyState.collectAsState()
    val history by customerViewModel.history.collectAsState()
    val isLoadingHistory by customerViewModel.isLoadingHistory.collectAsState()

    // Trigger verification and history load
    LaunchedEffect(userEmail) {
        if (userEmail.isNotBlank()) {
            customerViewModel.verifyAndLoad(userEmail, idToken)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Personal Health",
                    style = MaterialTheme.typography.headlineSmall,
                    color = CardioKeyColors.TextPrimary
                )
                Text(
                    text = "Multimodal Biometrics & Vitals",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary
                )
            }
            IconButton(onClick = { customerViewModel.refreshHistory(idToken) }) {
                if (isLoadingHistory) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = CardioKeyColors.NeonMint
                    )
                } else {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        tint = CardioKeyColors.TextSecondary
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // State Machine based on email verification and matching
        when (val state = verifyState) {
            is CustomerVerifyState.Verifying -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    CKLoadingRow("Verifying Google account authorization & security status…")
                }
            }

            is CustomerVerifyState.NotVerified -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = CardioKeyColors.ElectricCoral,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Account Access Restricted",
                                fontWeight = FontWeight.Bold,
                                color = CardioKeyColors.ElectricCoral
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                state.reason,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CardioKeyColors.TextSecondary
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    GradientButton(
                        text = "Sign Out",
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            is CustomerVerifyState.Verified -> {
                val profile = state.profile
                val latestSession: AuthSessionResponse? = history.firstOrNull()

                // Profile Welcome Banner
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Welcome, ${profile.firstName}",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = CardioKeyColors.TextPrimary
                                )
                                Spacer(Modifier.width(6.dp))
                                Icon(
                                    Icons.Default.Verified,
                                    contentDescription = "Verified Account",
                                    tint = CardioKeyColors.NeonMint,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = profile.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = CardioKeyColors.TextMuted
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Latest Biometric Authentication Status Card
                if (latestSession != null) {
                    CKCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LATEST BIOMETRIC SCAN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CardioKeyColors.TextMuted,
                                    letterSpacing = 1.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                StatusBadge(authenticated = latestSession.authenticated)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = if (latestSession.authenticated) "Verified Identity" else "Unverified Subject",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CardioKeyColors.TextPrimary
                                )
                                Text(
                                    text = "Timestamp: ${latestSession.timestamp.ifBlank { "Recent" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CardioKeyColors.TextMuted
                                )
                            }
                            ConfidenceGauge(confidence = latestSession.similarity)
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Live Health Analytics Grid
                    HealthMetricsGrid(
                        health = latestSession.healthScan,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (!isLoadingHistory) {
                    CKCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No biometric scans recorded yet. Once an Admin completes an authentication scan for you, your real-time vitals and telemetry will appear here.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CardioKeyColors.TextSecondary
                        )
                    }
                }
            }

            CustomerVerifyState.Idle -> Unit
        }
    }
}
