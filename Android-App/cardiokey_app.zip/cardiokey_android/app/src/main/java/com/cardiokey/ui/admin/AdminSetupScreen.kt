package com.cardiokey.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.ui.components.CKCard
import com.cardiokey.ui.components.CKErrorText
import com.cardiokey.ui.components.CKLoadingRow
import com.cardiokey.ui.components.CKSuccessText
import com.cardiokey.ui.components.CKTextField
import com.cardiokey.ui.components.GradientButton
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.DeviceLinkState
import com.cardiokey.viewmodel.SetupViewModel
import com.cardiokey.viewmodel.WifiSetupState

@Composable
fun AdminSetupScreen(viewModel: SetupViewModel) {
    val wifiState by viewModel.wifiState.collectAsState()
    val linkState by viewModel.linkState.collectAsState()

    var homeSsid by remember { mutableStateOf("") }
    var homePassword by remember { mutableStateOf("") }
    var flaskEndpoint by remember { mutableStateOf("https://your-backend-url.example.com/presign/auth") }
    
    var deviceIpInput by remember { mutableStateOf("") }
    var manualBackendUrl by remember { mutableStateOf("https://your-backend-url.example.com/") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Router,
                contentDescription = null,
                tint = CardioKeyColors.PurpleStart,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    "Device Setup",
                    style = MaterialTheme.typography.headlineSmall,
                    color = CardioKeyColors.TextPrimary
                )
                Text(
                    "ESP32 Wi-Fi provisioning in two stages",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // Stage 1
        SetupStageCard(
            stageNumber = 1,
            title = "Provision ESP32 via Setup Network",
            subtitle = "Join: CARDIOKEY-ESP32 → 192.168.4.1"
        ) {
            Text(
                "Connect your phone to the ESP32's temporary Wi-Fi network (CARDIOKEY-ESP32), " +
                        "then tap Check. This call goes to 192.168.4.1 — the device's AP mode address.",
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextSecondary
            )
            Spacer(Modifier.height(12.dp))

            when (val s = wifiState) {
                is WifiSetupState.NotOnSetupNetwork -> {
                    GradientButton(
                        text = "Check Setup Network (192.168.4.1)",
                        onClick = { viewModel.checkSetupAp() },
                        icon = Icons.Default.Wifi
                    )
                }
                is WifiSetupState.CheckingSetupAp -> CKLoadingRow("Checking for device at 192.168.4.1…")
                is WifiSetupState.ReadyToConfigure, is WifiSetupState.Submitting -> {
                    CKTextField(value = homeSsid, onValueChange = { homeSsid = it }, label = "Home Wi-Fi SSID")
                    Spacer(Modifier.height(8.dp))
                    CKTextField(
                        value = homePassword, onValueChange = { homePassword = it },
                        label = "Home Wi-Fi Password", isPassword = true
                    )
                    Spacer(Modifier.height(8.dp))
                    CKTextField(
                        value = flaskEndpoint, onValueChange = { flaskEndpoint = it },
                        label = "Flask Backend Presign URL"
                    )
                    Spacer(Modifier.height(12.dp))
                    if (wifiState is WifiSetupState.Submitting) {
                        CKLoadingRow("Sending credentials to 192.168.4.1…")
                    } else {
                        GradientButton(
                            text = "Send to Device (POST /wifi/configure)",
                            onClick = { viewModel.submitWifiCredentials(homeSsid, homePassword) },
                            enabled = homeSsid.isNotBlank()
                        )
                    }
                }
                is WifiSetupState.CredentialsAccepted -> {
                    CKSuccessText(
                        "✓ Device accepted credentials and is rebooting. " +
                                "Check the OLED for the new IP, rejoin your home Wi-Fi, then continue to Stage 2."
                    )
                }
                is WifiSetupState.Failed -> {
                    CKErrorText(s.message)
                    Spacer(Modifier.height(8.dp))
                    GradientButton(
                        text = "Retry",
                        onClick = { viewModel.checkSetupAp() }
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Stage 2
        SetupStageCard(
            stageNumber = 2,
            title = "Confirm Device on Home Network",
            subtitle = "LAN mode — enter ESP32 IP from OLED"
        ) {
            Text(
                "Rejoin your home Wi-Fi. Enter the ESP32's IP (shown on its OLED screen) and confirm the link.",
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextSecondary
            )
            Spacer(Modifier.height(12.dp))
            CKTextField(
                value = deviceIpInput, onValueChange = { deviceIpInput = it },
                label = "ESP32 IP (e.g. 10.80.62.96)",
                keyboardType = KeyboardType.Uri
            )
            Spacer(Modifier.height(12.dp))

            when (val ls = linkState) {
                is DeviceLinkState.Checking -> CKLoadingRow("Checking device at $deviceIpInput…")
                is DeviceLinkState.Linked -> {
                    CKSuccessText("✓ Device is reachable on home network.")
                    Spacer(Modifier.height(8.dp))
                    GradientButton(
                        text = "Save and Continue",
                        onClick = { viewModel.saveDeviceIp(deviceIpInput) }
                    )
                }
                is DeviceLinkState.Failed -> {
                    CKErrorText(ls.message)
                    Spacer(Modifier.height(8.dp))
                    GradientButton(
                        text = "Retry (GET /status)",
                        onClick = { viewModel.linkDeviceOnLan(deviceIpInput) },
                        enabled = deviceIpInput.isNotBlank()
                    )
                }
                is DeviceLinkState.Unlinked -> {
                    GradientButton(
                        text = "Confirm on Home Network (GET /status)",
                        onClick = { viewModel.linkDeviceOnLan(deviceIpInput) },
                        enabled = deviceIpInput.isNotBlank()
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Manual Overrides
        SetupStageCard(
            stageNumber = 0,
            title = "Manual Overrides",
            subtitle = "Use the Flask API root, not /presign/auth"
        ) {
            CKTextField(
                value = manualBackendUrl, onValueChange = { manualBackendUrl = it },
                label = "Flask Backend Base URL"
            )
            Spacer(Modifier.height(12.dp))
            GradientButton(
                text = "Save Backend URL",
                onClick = { viewModel.saveBackendUrl(manualBackendUrl) },
                enabled = manualBackendUrl.isNotBlank()
            )
        }
    }
}

@Composable
private fun SetupStageCard(
    stageNumber: Int,
    title: String,
    subtitle: String,
    content: @Composable ColumnScope.() -> Unit
) {
    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (stageNumber > 0) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(50))
                        .background(
                            Brush.horizontalGradient(
                                listOf(CardioKeyColors.PurpleStart, CardioKeyColors.PurpleEnd)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$stageNumber", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
            }
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = CardioKeyColors.TextPrimary)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
            }
        }
        Spacer(Modifier.height(16.dp))
        content()
    }
}
