package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.repository.DeviceRepository
import com.cardiokey.data.repository.FlaskRepository
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Starting : AuthUiState()
    data class Recording(val sessionId: String, val totalSeconds: Int = 16) : AuthUiState()
    data class Uploading(val sessionId: String) : AuthUiState()
    data class Processing(val sessionId: String) : AuthUiState()
    data class Result(val session: AuthSessionResponse) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val deviceRepo = DeviceRepository(application)
    private var flaskRepo: FlaskRepository? = null

    private val _state = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    private val _showGroundTruth = MutableStateFlow<AuthSessionResponse?>(null)
    val showGroundTruth: StateFlow<AuthSessionResponse?> = _showGroundTruth.asStateFlow()
    private val _groundTruthSent = MutableStateFlow<Boolean?>(null)
    val groundTruthSent: StateFlow<Boolean?> = _groundTruthSent.asStateFlow()

    private suspend fun getRepo(): FlaskRepository {
        return flaskRepo ?: run {
            val url = prefs.backendUrl.first()?.takeIf { it.isNotBlank() }
                ?: "https://your-backend-url.example.com/"
            FlaskRepository(NetworkModule.flaskApi(url)).also { flaskRepo = it }
        }
    }

    fun startAuthScan(userId: String? = null) {
        if (_state.value !is AuthUiState.Idle) return
        viewModelScope.launch {
            _state.value = AuthUiState.Starting
            _showGroundTruth.value = null
            _groundTruthSent.value = null
            try {
                val start = deviceRepo.startAuthentication(userId)
                val sessionId = start.sessionId
                if (sessionId.isBlank()) error("ESP32 did not return a session ID.")
                _state.value = AuthUiState.Recording(sessionId, 16)

                var consecutiveErrors = 0
                var uploaded = false
                repeat(50) {
                    delay(1000L)
                    val status = try {
                        deviceRepo.getSessionStatus(sessionId).also { consecutiveErrors = 0 }
                    } catch (e: Exception) {
                        consecutiveErrors++
                        if (consecutiveErrors >= 5) throw IllegalStateException(
                            "Lost connection to ESP32 while checking scan status: ${e.message}"
                        )
                        return@repeat
                    }
                    when (status.status.lowercase()) {
                        "recording" -> _state.value = AuthUiState.Recording(sessionId, 16)
                        "uploading" -> _state.value = AuthUiState.Uploading(sessionId)
                        "upload_ok" -> {
                            uploaded = true
                            getRepo().reportDeviceStatus(sessionId, "upload_ok")
                                .onFailure { android.util.Log.w("AuthViewModel", "Device status update notice: ${it.message}") }
                            _state.value = AuthUiState.Processing(sessionId)
                            pollAuthResult(sessionId)
                            return@launch
                        }
                        "upload_failed" -> {
                            runCatching { getRepo().reportDeviceStatus(sessionId, "upload_failed") }
                            error("ESP32 recording upload failed. Check Wi-Fi, S3 presigning and device logs.")
                        }
                    }
                }
                if (!uploaded) error("Timed out waiting for ESP32 to finish the 15-second scan and upload.")
            } catch (e: Exception) {
                _state.value = AuthUiState.Error(e.message ?: "Failed to start authentication scan.")
            }
        }
    }

    private suspend fun pollAuthResult(sessionId: String) {
        repeat(120) {
            delay(3000L)
            var completed = false
            getRepo().getSessionStatus(sessionId).onSuccess { session ->
                when {
                    session.status.equals("failed", true) -> {
                        _state.value = AuthUiState.Error("Backend biometric processing failed for this session.")
                        completed = true
                    }
                    session.status.equals("complete", true) || session.predictedUserId != null -> {
                        _state.value = AuthUiState.Result(session)
                        _showGroundTruth.value = session
                        completed = true
                    }
                }
            }
            if (completed) return
        }
        if (_state.value is AuthUiState.Processing) {
            _state.value = AuthUiState.Error(
                "The 15-second recording was uploaded, but the backend has not returned a biometric verdict yet. Check the EC2 processing worker and auth_sessions row. Upload success is not an authentication match."
            )
        }
    }

    fun submitGroundTruth(sessionId: String, actualUserId: String) {
        viewModelScope.launch {
            getRepo().verifyGroundTruth(sessionId, actualUserId)
                .onSuccess { _groundTruthSent.value = true }
                .onFailure { _groundTruthSent.value = false }
            _showGroundTruth.value = null
        }
    }

    fun dismissGroundTruth() { _showGroundTruth.value = null }

    fun reset() {
        _state.value = AuthUiState.Idle
        _showGroundTruth.value = null
        _groundTruthSent.value = null
    }
}
