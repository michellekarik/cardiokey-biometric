package com.cardiokey.viewmodel

import android.app.Application
import android.util.Log
import android.util.Patterns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.*
import com.cardiokey.data.repository.FlaskRepository
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class CreateUserState {
    object Idle : CreateUserState()
    object Loading : CreateUserState()
    data class Success(val user: UserProfile) : CreateUserState()
    data class Error(val message: String) : CreateUserState()
}

class UserManagementViewModel(application: Application) : AndroidViewModel(application) {

    private val tag = "CreateUser"

    private val prefs = AppPreferences(application)
    private var repo: FlaskRepository? = null

    private val _users = MutableStateFlow<List<UserProfile>>(emptyList())
    val users: StateFlow<List<UserProfile>> = _users.asStateFlow()

    private val _usersError = MutableStateFlow<String?>(null)
    val usersError: StateFlow<String?> = _usersError.asStateFlow()

    private val _createState = MutableStateFlow<CreateUserState>(CreateUserState.Idle)
    val createState: StateFlow<CreateUserState> = _createState.asStateFlow()

    private val _userHistories = MutableStateFlow<Map<String, List<AuthSessionResponse>>>(emptyMap())
    val userHistories: StateFlow<Map<String, List<AuthSessionResponse>>> = _userHistories.asStateFlow()

    private val _isLoadingUsers = MutableStateFlow(false)
    val isLoadingUsers: StateFlow<Boolean> = _isLoadingUsers.asStateFlow()

    private suspend fun getRepo(): FlaskRepository {
        return repo ?: run {
            val url = prefs.backendUrl.first()?.takeIf { it.isNotBlank() } ?: "https://your-backend-url.example.com/"
            val newRepo = FlaskRepository(NetworkModule.flaskApi(url))
            repo = newRepo
            newRepo
        }
    }

    fun refreshUsers() {
        viewModelScope.launch {
            _isLoadingUsers.value = true
            _usersError.value = null
            getRepo().getAllUsers()
                .onSuccess { fromBackend -> _users.value = fromBackend }
                .onFailure { e ->
                    _usersError.value = e.message ?: "Could not load users from backend."
                    Log.e(tag, "User directory request failed", e)
                }
            _isLoadingUsers.value = false
        }
    }

    /**
     * Creates the user in Supabase / Backend.
     */
    fun createUser(
        firstName: String, lastName: String,
        email: String, age: Int, sex: String
    ) {
        val cleanEmail = email.trim()

        if (cleanEmail.contains(" ") || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            _createState.value = CreateUserState.Error(
                "Invalid email address. Remove any spaces (e.g. name@gmail.com)."
            )
            return
        }

        viewModelScope.launch {
            _createState.value = CreateUserState.Loading
            Log.d(tag, "Registering user in backend/Supabase for $cleanEmail")

            val req = CreateUserRequest(firstName.trim(), lastName.trim(), cleanEmail, age, sex)
            getRepo().createUser(req)
                .onSuccess { newUser ->
                    Log.d(tag, "User created successfully in backend/Supabase: ${newUser.userId}")
                    _users.value = _users.value.filter { !it.email.equals(cleanEmail, true) } + newUser
                    _createState.value = CreateUserState.Success(newUser)
                }
                .onFailure { e ->
                    Log.e(tag, "User creation failed; no local user was fabricated", e)
                    _createState.value = CreateUserState.Error(
                        e.message ?: "User could not be saved. Check Flask and Supabase."
                    )
                }
        }
    }

    fun loadUserHistory(userId: String) {
        if (_userHistories.value.containsKey(userId)) return
        viewModelScope.launch {
            getRepo().getUserHistory(userId)
                .onSuccess { history ->
                    _userHistories.value = _userHistories.value + (userId to history)
                }
                .onFailure { e ->
                    Log.e(tag, "Could not load user history for $userId", e)
                }
        }
    }

    fun resetCreateState() {
        _createState.value = CreateUserState.Idle
    }
}