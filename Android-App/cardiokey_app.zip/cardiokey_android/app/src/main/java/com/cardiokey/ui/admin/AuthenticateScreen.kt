package com.cardiokey.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.UserProfile
import com.cardiokey.ui.components.*
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.AuthUiState
import com.cardiokey.viewmodel.AuthViewModel
import com.cardiokey.viewmodel.UserManagementViewModel
import kotlinx.coroutines.delay

@Composable
fun AuthenticateScreen(
    authVm: AuthViewModel,
    userVm: UserManagementViewModel
) {
    val state by authVm.state.collectAsState()
    val showGroundTruth by authVm.showGroundTruth.collectAsState()
    val users by userVm.users.collectAsState()
    val groundTruthSent by authVm.groundTruthSent.collectAsState()

    LaunchedEffect(Unit) { userVm.refreshUsers() }

    // Ground Truth Dialog
    showGroundTruth?.let { session ->
        GroundTruthBottomSheet(
            session = session,
            allUsers = users,
            onSubmit = { actualUserId -> authVm.submitGroundTruth(session.sessionId, actualUserId) },
            onDismiss = { authVm.dismissGroundTruth() }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Fingerprint, null, tint = CardioKeyColors.NeonMint, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("1:N Authentication Scan", style = MaterialTheme.typography.headlineSmall)
                Text("15-second biometric identification", style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary)
            }
        }

        Spacer(Modifier.height(24.dp))

        if (groundTruthSent == true) {
            CKCard(modifier = Modifier.fillMaxWidth()) {
                CKSuccessText("✓ Ground truth submitted. Label recorded for accuracy tracking.")
            }
            Spacer(Modifier.height(12.dp))
        }

        when (val s = state) {
            is AuthUiState.Idle -> {
                IdleAuthCard { authVm.startAuthScan() }
            }
            is AuthUiState.Starting -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    CKLoadingRow("Initiating scan session…")
                }
            }
            is AuthUiState.Recording -> {
                AuthRecordingCard(sessionId = s.sessionId, totalSeconds = s.totalSeconds)
            }
            is AuthUiState.Uploading -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    CKLoadingRow("Uploading biometric data to Flask backend…")
                }
            }
            is AuthUiState.Processing -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    CKLoadingRow("Backend is running 1:N biometric matching…")
                }
            }
            is AuthUiState.Result -> {
                AuthResultCard(session = s.session)
                Spacer(Modifier.height(16.dp))
                HealthMetricsGrid(health = s.session.healthScan)
                Spacer(Modifier.height(16.dp))
                GradientButton(
                    text = "New Scan",
                    onClick = { authVm.reset() },
                    icon = Icons.Default.Refresh,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            is AuthUiState.Error -> {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Error, null, tint = CardioKeyColors.ElectricCoral,
                            modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        CKErrorText(s.message)
                    }
                }
                Spacer(Modifier.height(12.dp))
                GradientButton(text = "Dismiss", onClick = { authVm.reset() },
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun IdleAuthCard(onStart: () -> Unit) {
    CKCard(modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(40.dp))
                    .background(CardioKeyColors.NeonMint.copy(alpha = 0.1f))
                    .border(2.dp, CardioKeyColors.NeonMint.copy(alpha = 0.4f), RoundedCornerShape(40.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Fingerprint, null, tint = CardioKeyColors.NeonMint,
                    modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Ready for 1:N Scan", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                "Place subject on sensor. Tap Start to begin 15-second capture.",
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
            GradientButton(
                text = "Start 1:N Scan",
                onClick = onStart,
                icon = Icons.Default.PlayArrow,
                modifier = Modifier.fillMaxWidth(0.7f)
            )
        }
    }
}

@Composable
private fun AuthRecordingCard(sessionId: String, totalSeconds: Int) {
    var secondsRemaining by remember(sessionId) { mutableIntStateOf(totalSeconds) }
    LaunchedEffect(sessionId) {
        while (secondsRemaining > 0) { delay(1000L); secondsRemaining-- }
    }
    val progress = secondsRemaining.toFloat() / totalSeconds.toFloat()

    CKCard(modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = CardioKeyColors.ElectricCoral,
                    trackColor = CardioKeyColors.CardBorder,
                    strokeWidth = 10.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "%02d".format(secondsRemaining),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = CardioKeyColors.ElectricCoral
                    )
                    Text("seconds", fontSize = 10.sp, color = CardioKeyColors.TextMuted)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Scanning…", fontWeight = FontWeight.SemiBold, color = CardioKeyColors.TextPrimary)
            Text(
                "ECG + PPG capture in progress (${sessionId.take(8)}…)",
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextMuted
            )
        }
    }
}

@Composable
private fun AuthResultCard(session: AuthSessionResponse) {
    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                StatusBadge(authenticated = session.authenticated)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = session.predictedUser ?: "Unknown",
                    style = MaterialTheme.typography.titleMedium,
                    color = CardioKeyColors.TextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Threshold: ${"%.3f".format(session.threshold)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
                Text(
                    "Margin: ${"%.3f".format(session.margin)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
                Text(
                    "2nd Best: ${"%.3f".format(session.secondBestSimilarity)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
            }
            ConfidenceGauge(confidence = session.similarity)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroundTruthBottomSheet(
    session: AuthSessionResponse,
    allUsers: List<UserProfile>,
    onSubmit: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedUserId by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CardioKeyColors.SurfaceNavy
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                "Ground Truth Validation",
                style = MaterialTheme.typography.titleLarge,
                color = CardioKeyColors.TextPrimary
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Who was actually using CardioKey during this scan?",
                style = MaterialTheme.typography.bodyMedium,
                color = CardioKeyColors.TextSecondary
            )
            Spacer(Modifier.height(16.dp))

            // Predicted user chip (highlighted)
            session.predictedUserId?.let { predictedId ->
                GroundTruthChip(
                    label = session.predictedUser?.let { "$it (Predicted)" } ?: "Predicted User",
                    isSelected = selectedUserId == predictedId,
                    isPredicted = true,
                    onClick = { selectedUserId = predictedId }
                )
                Spacer(Modifier.height(8.dp))
            }

            // All registered users
            val otherUsers = allUsers.filter { it.userId != session.predictedUserId }
            if (otherUsers.isNotEmpty()) {
                Text("Other Users:", style = MaterialTheme.typography.labelMedium,
                    color = CardioKeyColors.TextMuted)
                Spacer(Modifier.height(8.dp))
                otherUsers.forEach { user ->
                    GroundTruthChip(
                        label = "${user.firstName} ${user.lastName}",
                        isSelected = selectedUserId == user.userId,
                        isPredicted = false,
                        onClick = { selectedUserId = user.userId }
                    )
                    Spacer(Modifier.height(6.dp))
                }
            }

            // Unknown option
            GroundTruthChip(
                label = "Other / Unknown",
                isSelected = selectedUserId == "unknown",
                isPredicted = false,
                onClick = { selectedUserId = "unknown" }
            )

            Spacer(Modifier.height(20.dp))
            GradientButton(
                text = "Submit Ground Truth",
                onClick = { if (selectedUserId.isNotBlank()) onSubmit(selectedUserId) },
                enabled = selectedUserId.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                Text("Skip", color = CardioKeyColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun GroundTruthChip(label: String, isSelected: Boolean, isPredicted: Boolean, onClick: () -> Unit) {
    val borderColor = when {
        isSelected -> CardioKeyColors.NeonMint
        isPredicted -> CardioKeyColors.PurpleStart
        else -> CardioKeyColors.CardBorder
    }
    val bgColor = when {
        isSelected -> CardioKeyColors.NeonMint.copy(alpha = 0.15f)
        isPredicted -> CardioKeyColors.PurpleStart.copy(alpha = 0.1f)
        else -> Color.Transparent
    }

    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp)),
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelected) {
                Icon(Icons.Default.CheckCircle, null, tint = CardioKeyColors.NeonMint,
                    modifier = Modifier.size(18.dp))
            } else {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .border(1.5.dp, borderColor, RoundedCornerShape(9.dp))
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                label,
                color = if (isSelected) CardioKeyColors.NeonMint else CardioKeyColors.TextPrimary,
                fontWeight = if (isPredicted) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
