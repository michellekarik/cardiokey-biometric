package com.cardiokey.data.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserProfile(
    @SerialName("user_id") val userId: String,
    @SerialName("first_name") val firstName: String,
    @SerialName("last_name") val lastName: String,
    @SerialName("email") val email: String,
    @SerialName("age") val age: Int,
    @SerialName("sex") val sex: String,
    @SerialName("is_verified") val isVerified: Boolean = false,
    @SerialName("role") val role: String = "CUSTOMER",
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class CreateUserRequest(
    @SerialName("first_name") val firstName: String,
    @SerialName("last_name") val lastName: String,
    @SerialName("email") val email: String,
    @SerialName("age") val age: Int,
    @SerialName("sex") val sex: String
)

@Serializable
data class HealthScanAnalytics(
    @SerialName("heart_rate_bpm") val heartRateBpm: Double? = null,
    @SerialName("hrv_rmssd_ms") val hrvRmssdMs: Double? = null,
    @SerialName("hrv_sdnn_ms") val hrvSdnnMs: Double? = null,
    @SerialName("respiratory_rate_rpm") val respiratoryRateRpm: Double? = null,
    @SerialName("spo2_percent") val spo2Percent: Double? = null,
    @SerialName("perfusion_index_percent") val perfusionIndexPercent: Double? = null,
    @SerialName("pat_median_ms") val patMedianMs: Double? = null,
    @SerialName("stress_level") val stressLevel: String? = null,
    @SerialName("afib_risk") val afibRisk: String? = null
)

@Serializable
data class AuthSessionResponse(
    @SerialName("session_id") val sessionId: String,
    @SerialName("authenticated") val authenticated: Boolean,
    @SerialName("predicted_user") val predictedUser: String? = null,
    @SerialName("predicted_user_id") val predictedUserId: String? = null,
    @SerialName("similarity") val similarity: Double = 0.0,
    @SerialName("second_best_similarity") val secondBestSimilarity: Double = 0.0,
    @SerialName("margin") val margin: Double = 0.0,
    @SerialName("threshold") val threshold: Double = 0.0,
    @SerialName("health_scan") val healthScan: HealthScanAnalytics? = null,
    @SerialName("timestamp") val timestamp: String = "",
    @SerialName("status") val status: String? = null,
    @SerialName("session_type") val sessionType: String? = null
)

@Serializable
data class GroundTruthValidationRequest(
    @SerialName("session_id") val sessionId: String,
    @SerialName("actual_user_id") val actualUserId: String
)

@Serializable
data class AdminSystemStats(
    @SerialName("total_registered_users") val totalRegisteredUsers: Int = 0,
    @SerialName("verified_users_count") val verifiedUsersCount: Int = 0,
    @SerialName("total_auth_attempts") val totalAuthAttempts: Int = 0,
    @SerialName("system_accuracy_rate") val systemAccuracyRate: Double = 0.0,
    @SerialName("average_margin") val averageMargin: Double = 0.0
)

@Serializable
data class SetupStatusResponse(
    @SerialName("status") val status: String = "idle",
    @SerialName("state") val state: String = "idle",
    @SerialName("firmware_version") val firmwareVersion: String? = null,
    @SerialName("fw_version") val fwVersion: String? = null,
    @SerialName("wifi") val wifi: Boolean = false,
    @SerialName("ip") val ip: String? = null
)

@Serializable
data class WifiConfigureRequest(
    @SerialName("ssid") val ssid: String,
    @SerialName("password") val password: String,
    @SerialName("flask_endpoint") val flaskEndpoint: String = ""
)

@Serializable
data class WifiConfigureResponse(
    @SerialName("accepted") val accepted: Boolean = false,
    @SerialName("success") val success: Boolean = false,
    @SerialName("connected") val connected: Boolean = false,
    @SerialName("message") val message: String = "",
    @SerialName("ip") val ip: String? = null
)

@Serializable
data class DeviceStatusResponse(
    @SerialName("status") val status: String,
    @SerialName("device_id") val deviceId: String? = null,
    @SerialName("firmware") val firmware: String? = null,
    @SerialName("ecg_ready") val ecgReady: Boolean = false,
    @SerialName("ppg_ready") val ppgReady: Boolean = false
)

@Serializable
data class SessionStartResponse(
    @SerialName("session_id") val sessionId: String,
    @SerialName("duration_seconds") val durationSeconds: Int = 0,
    @SerialName("status") val status: String = "recording"
)

@Serializable
data class SessionStatusResponse(
    @SerialName("session_id") val sessionId: String,
    @SerialName("status") val status: String,  // "recording", "uploading", "complete", "failed"
    @SerialName("result") val result: AuthSessionResponse? = null,
    @SerialName("error") val error: String? = null
)

// UI-level state sealed classes
sealed class AppRole {
    object None : AppRole()
    object Admin : AppRole()
    data class Customer(val email: String, val idToken: String) : AppRole()
}
