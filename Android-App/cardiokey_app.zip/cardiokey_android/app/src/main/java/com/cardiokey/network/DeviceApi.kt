package com.cardiokey.network

import com.cardiokey.data.models.DeviceStatusResponse
import com.cardiokey.data.models.SessionStartResponse
import com.cardiokey.data.models.SessionStatusResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/** Calls made ONLY once both phone and ESP32 are on the normal home Wi-Fi.
 * Base URL: http://<device-ip>/ — device-ip is entered by the admin. */
interface DeviceApi {
    @GET("status")
    suspend fun getStatus(): DeviceStatusResponse

    @POST("enroll/start")
    suspend fun startEnroll(@Body body: Map<String, String>): SessionStartResponse

    @POST("auth/start")
    suspend fun startAuth(@Body body: Map<String, String> = emptyMap()): SessionStartResponse

    @GET("session/{id}/status")
    suspend fun sessionStatus(@Path("id") sessionId: String): SessionStatusResponse

    @POST("session/{id}/cancel")
    suspend fun cancelSession(@Path("id") sessionId: String)
}
