package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.repository.DeviceRepository
import com.cardiokey.data.repository.FlaskRepository
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed class EnrollUiState {
    object Idle : EnrollUiState()
    object Preparing : EnrollUiState()
    object CheckingSensors : EnrollUiState()
    data class Recording(val sessionId: String, val totalSeconds: Int = 301) : EnrollUiState()
    object Uploading : EnrollUiState()
    object Processing : EnrollUiState()
    data class Complete(val sessionId: String) : EnrollUiState()
    data class RetakeRequired(val reason: String) : EnrollUiState()
    data class Error(val message: String) : EnrollUiState()
}

class EnrollViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)
    private val deviceRepo = DeviceRepository(application)
    private var flaskRepo: FlaskRepository? = null

    private val _state = MutableStateFlow<EnrollUiState>(EnrollUiState.Idle)
    val state: StateFlow<EnrollUiState> = _state.asStateFlow()

    private suspend fun getFlaskRepo(): FlaskRepository {
        return flaskRepo ?: run {
            val url = prefs.backendUrl.first()?.takeIf { it.isNotBlank() }
                ?: "https://your-backend-url.example.com/"
            FlaskRepository(NetworkModule.flaskApi(url)).also { flaskRepo = it }
        }
    }

    fun startEnrollment(userId: String) {
        if (_state.value !is EnrollUiState.Idle) return
        viewModelScope.launch {
            _state.value = EnrollUiState.Preparing
            try {
                require(userId.isNotBlank()) { "Select a registered user first." }
                _state.value = EnrollUiState.CheckingSensors
                val start = deviceRepo.startEnrollment(userId)
                val sessionId = start.sessionId
                if (sessionId.isBlank()) error("ESP32 did not return a session ID.")
                _state.value = EnrollUiState.Recording(sessionId, 301)

                var consecutiveErrors = 0
                repeat(250) {
                    delay(1500L)
                    val status = try {
                        deviceRepo.getSessionStatus(sessionId).also { consecutiveErrors = 0 }
                    } catch (e: Exception) {
                        consecutiveErrors++
                        // Allow more grace period during heavy S3 HTTPS upload before timing out
                        if (consecutiveErrors >= 25) {
                            // Check if the backend has already processed and completed the enrollment
                            val backendStatus = runCatching { getFlaskRepo().getSessionStatus(sessionId) }.getOrNull()?.getOrNull()
                            if (backendStatus?.status.equals("complete", true)) {
                                _state.value = EnrollUiState.Complete(sessionId)
                                return@launch
                            }
                            throw IllegalStateException(
                                "Lost connection to ESP32 while checking recording status: ${e.message}"
                            )
                        }
                        return@repeat
                    }

                    when (status.status.lowercase()) {
                        "recording" -> _state.value = EnrollUiState.Recording(sessionId, 301)
                        "uploading" -> _state.value = EnrollUiState.Uploading
                        "upload_ok" -> {
                            _state.value = EnrollUiState.Processing
                            getFlaskRepo().reportDeviceStatus(sessionId, "upload_ok")
                                .onFailure { android.util.Log.w("EnrollViewModel", "Notice updating Supabase: ${it.message}") }
                            _state.value = EnrollUiState.Complete(sessionId)
                            return@launch
                        }
                        "upload_failed" -> {
                            runCatching { getFlaskRepo().reportDeviceStatus(sessionId, "upload_failed") }
                            _state.value = EnrollUiState.RetakeRequired("ESP32 could not upload the recording. Check Wi-Fi, S3 presigning and the device serial log.")
                            return@launch
                        }
                        else -> {
                            // If ESP32 finished and already cleared its state, check backend directly
                            val backendStatus = runCatching { getFlaskRepo().getSessionStatus(sessionId) }.getOrNull()?.getOrNull()
                            if (backendStatus?.status.equals("complete", true)) {
                                _state.value = EnrollUiState.Complete(sessionId)
                                return@launch
                            }
                            _state.value = EnrollUiState.Recording(sessionId, 301)
                        }
                    }
                }
                if (_state.value !is EnrollUiState.Complete &&
                    _state.value !is EnrollUiState.RetakeRequired) {
                    _state.value = EnrollUiState.Error("Timed out waiting for ESP32 recording/upload. Check the device IP and serial monitor.")
                }
            } catch (e: Exception) {
                _state.value = EnrollUiState.Error(e.message ?: "Enrollment could not be started.")
            }
        }
    }

    fun reset() {
        _state.value = EnrollUiState.Idle
    }
}
