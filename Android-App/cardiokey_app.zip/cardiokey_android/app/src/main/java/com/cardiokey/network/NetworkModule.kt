package com.cardiokey.network

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object NetworkModule {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }
    private val contentType = "application/json".toMediaType()

    private fun loggingClient(timeoutSeconds: Long): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val builder = OkHttpClient.Builder()
            .connectTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .writeTimeout(timeoutSeconds, TimeUnit.SECONDS)
            .addInterceptor(logging)

        // Bypass SSL validation for development / sslip.io self-signed certificates
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, SecureRandom())
            val sslSocketFactory = sslContext.socketFactory

            builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            builder.hostnameVerifier { _, _ -> true }
        } catch (e: Exception) {
            // Fallback to standard client if SSL manipulation fails
        }

        return builder.build()
    }

    /** The setup AP is flaky by nature — short timeout so the UI can retry. */
    fun setupApi(): SetupApi = Retrofit.Builder()
        .baseUrl("http://192.168.4.1/")
        .client(loggingClient(timeoutSeconds = 6))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(SetupApi::class.java)

    /** Home LAN device calls: base URL depends on the IP the admin entered. */
    fun deviceApi(deviceIp: String): DeviceApi = Retrofit.Builder()
        .baseUrl("http://${deviceIp.trim().removePrefix("http://").removePrefix("https://").trimEnd('/')}/")
        .client(loggingClient(timeoutSeconds = 10))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(DeviceApi::class.java)

    /** Flask backend API: longer timeout for internet calls. */
    fun flaskApi(baseUrl: String): FlaskApiService = Retrofit.Builder()
        .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
        .client(loggingClient(timeoutSeconds = 30))
        .addConverterFactory(json.asConverterFactory(contentType))
        .build()
        .create(FlaskApiService::class.java)
}
