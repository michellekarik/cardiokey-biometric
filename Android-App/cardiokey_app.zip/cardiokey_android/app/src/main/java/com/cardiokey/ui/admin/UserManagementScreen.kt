package com.cardiokey.ui.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.UserProfile
import com.cardiokey.ui.components.*
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.CreateUserState
import com.cardiokey.viewmodel.UserManagementViewModel

@Composable
fun UserManagementScreen(viewModel: UserManagementViewModel) {
    val users by viewModel.users.collectAsState()
    val createState by viewModel.createState.collectAsState()
    val isLoadingUsers by viewModel.isLoadingUsers.collectAsState()
    val usersError by viewModel.usersError.collectAsState()
    val userHistories by viewModel.userHistories.collectAsState()

    var showOnboardingForm by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refreshUsers() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 20.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("User Management", style = MaterialTheme.typography.headlineSmall)
                    Text("Onboarding & User Directory", style = MaterialTheme.typography.bodySmall,
                        color = CardioKeyColors.TextSecondary)
                }
                GradientButton(
                    text = if (showOnboardingForm) "Cancel" else "+ New User",
                    onClick = {
                        showOnboardingForm = !showOnboardingForm
                        viewModel.resetCreateState()
                    }
                )
            }
        }

        // Onboarding Form
        if (showOnboardingForm) {
            item {
                OnboardingFormCard(
                    createState = createState,
                    onSubmit = { fn, ln, email, age, sex ->
                        viewModel.createUser(fn, ln, email, age, sex)
                    },
                    onDismiss = {
                        showOnboardingForm = false
                        viewModel.resetCreateState()
                    }
                )
            }
        }

        // Directory Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Registered Users (${users.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = CardioKeyColors.TextPrimary
                )
                if (isLoadingUsers) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = CardioKeyColors.NeonMint
                    )
                } else {
                    IconButton(onClick = { viewModel.refreshUsers() }) {
                        Icon(Icons.Default.Refresh, null, tint = CardioKeyColors.TextSecondary)
                    }
                }
            }
        }

        if (usersError != null) {
            item { CKErrorText(usersError!!) }
        }

        if (users.isEmpty() && !isLoadingUsers) {
            item {
                CKCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "No registered users. Add one using the \"+ New User\" button.",
                        color = CardioKeyColors.TextMuted,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // User Cards (Expandable)
        items(users, key = { it.userId }) { user ->
            ExpandableUserCard(
                user = user,
                history = userHistories[user.userId],
                onExpand = { viewModel.loadUserHistory(user.userId) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OnboardingFormCard(
    createState: CreateUserState,
    onSubmit: (String, String, String, Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("") }
    var sex by remember { mutableStateOf("Male") }
    var sexExpanded by remember { mutableStateOf(false) }

    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PersonAdd, null, tint = CardioKeyColors.PurpleStart,
                modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text("Get To Know You", fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary)
        }
        Text(
            "New user onboarding — an email verification link will be sent.",
            style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextMuted
        )
        Spacer(Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CKTextField(value = firstName, onValueChange = { firstName = it },
                label = "First Name", modifier = Modifier.weight(1f))
            CKTextField(value = lastName, onValueChange = { lastName = it },
                label = "Last Name", modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        CKTextField(value = email, onValueChange = { email = it }, label = "Email")
        Spacer(Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CKTextField(
                value = ageText,
                onValueChange = { if (it.all { c -> c.isDigit() }) ageText = it },
                label = "Age",
                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number,
                modifier = Modifier.weight(1f)
            )
            ExposedDropdownMenuBox(
                expanded = sexExpanded,
                onExpandedChange = { sexExpanded = it },
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    value = sex,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Sex") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(sexExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CardioKeyColors.PurpleStart,
                        unfocusedBorderColor = CardioKeyColors.CardBorder,
                        focusedTextColor = CardioKeyColors.TextPrimary,
                        unfocusedTextColor = CardioKeyColors.TextPrimary
                    )
                )
                ExposedDropdownMenu(
                    expanded = sexExpanded,
                    onDismissRequest = { sexExpanded = false },
                    modifier = Modifier.background(CardioKeyColors.SurfaceNavy)
                ) {
                    listOf("Male", "Female", "Other").forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option, color = CardioKeyColors.TextPrimary) },
                            onClick = { sex = option; sexExpanded = false }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        when (createState) {
            is CreateUserState.Idle -> {
                GradientButton(
                    text = "Create User & Save to Supabase",
                    onClick = {
                        val age = ageText.toIntOrNull() ?: return@GradientButton
                        onSubmit(firstName, lastName, email, age, sex)
                    },
                    enabled = firstName.isNotBlank() && lastName.isNotBlank() &&
                            email.isNotBlank() && ageText.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            is CreateUserState.Loading -> CKLoadingRow("Creating user in Supabase…")
            is CreateUserState.Success -> {
                CKSuccessText(
                    "✓ User created and saved to Supabase: ${createState.user.email}. " +
                            "The profile is now available for enrollment."
                )
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onDismiss) {
                    Text("Close", color = CardioKeyColors.PurpleStart)
                }
            }
            is CreateUserState.Error -> {
                CKErrorText(createState.message)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = {
                    val age = ageText.toIntOrNull()
                    if (age != null && firstName.isNotBlank() && lastName.isNotBlank() && email.isNotBlank()) {
                        onSubmit(firstName, lastName, email, age, sex)
                    }
                }) {
                    Text("Retry saving user", color = CardioKeyColors.PurpleStart)
                }
            }
        }
    }
}

@Composable
fun ExpandableUserCard(
    user: UserProfile,
    history: List<AuthSessionResponse>?,
    onExpand: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val latestSession = history?.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardioKeyColors.SurfaceNavy)
            .border(1.dp, CardioKeyColors.CardBorder, RoundedCornerShape(16.dp))
            .animateContentSize()
    ) {
        // Card Header (always visible)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    isExpanded = !isExpanded
                    if (isExpanded && history == null) onExpand()
                }
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(CardioKeyColors.PurpleStart, CardioKeyColors.PurpleEnd)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${user.firstName.firstOrNull() ?: "?"}${user.lastName.firstOrNull() ?: ""}",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${user.firstName} ${user.lastName}",
                        fontWeight = FontWeight.SemiBold,
                        color = CardioKeyColors.TextPrimary
                    )
                    if (user.isVerified) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.Verified, null, tint = CardioKeyColors.NeonMint,
                            modifier = Modifier.size(14.dp))
                    }
                }
                Text(user.email, style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary)
                Text(
                    "Age: ${user.age} · ${user.sex}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextMuted
                )
            }
            latestSession?.let {
                StatusBadge(authenticated = it.authenticated, sessionType = it.sessionType)
                Spacer(Modifier.width(8.dp))
            }
            Icon(
                if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                null,
                tint = CardioKeyColors.TextSecondary
            )
        }

        // Expanded Content — Customer View for this specific user
        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardioKeyColors.InputBackground)
                    .padding(16.dp)
            ) {
                HorizontalDivider(color = CardioKeyColors.DividerLine)
                Spacer(Modifier.height(12.dp))

                if (history == null) {
                    CKLoadingRow("Loading user history…")
                } else if (history.isEmpty()) {
                    Text(
                        "No authentication sessions recorded for this user.",
                        color = CardioKeyColors.TextMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    // Latest auth result
                    latestSession?.let { session ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    if (session.sessionType.equals("enroll", ignoreCase = true)) "Baseline Enrollment Result" else "Latest Auth Result",
                                    fontWeight = FontWeight.SemiBold,
                                    color = CardioKeyColors.TextPrimary
                                )
                                StatusBadge(authenticated = session.authenticated, sessionType = session.sessionType)
                                Spacer(Modifier.height(4.dp))
                                if (!session.sessionType.equals("enroll", ignoreCase = true)) {
                                    Text(
                                        "Predicted: ${session.predictedUser ?: "N/A"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CardioKeyColors.TextSecondary
                                    )
                                    Text(
                                        "Margin: ${"%.3f".format(session.margin)} | Threshold: ${"%.3f".format(session.threshold)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CardioKeyColors.TextMuted
                                    )
                                }
                            }
                            if (!session.sessionType.equals("enroll", ignoreCase = true)) {
                                ConfidenceGauge(confidence = session.similarity)
                            }
                        }
                        Spacer(Modifier.height(16.dp))

                        // Health Metrics
                        session.healthScan?.let { health ->
                            HealthMetricsGrid(health = health)
                            Spacer(Modifier.height(16.dp))
                        }
                    }

                    // Full History
                    Text(
                        "Authentication History (${history.size} sessions)",
                        fontWeight = FontWeight.SemiBold,
                        color = CardioKeyColors.TextPrimary
                    )
                    Spacer(Modifier.height(8.dp))
                    history.take(5).forEach { session ->
                        HistorySessionRow(session)
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 6.dp),
                            color = CardioKeyColors.DividerLine
                        )
                    }
                    if (history.size > 5) {
                        Text(
                            "+ ${history.size - 5} more sessions",
                            style = MaterialTheme.typography.bodySmall,
                            color = CardioKeyColors.TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HistorySessionRow(session: AuthSessionResponse) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                session.timestamp.ifBlank { "Unknown time" },
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextSecondary
            )
            Text(
                session.predictedUser ?: "Unknown",
                style = MaterialTheme.typography.bodySmall,
                color = CardioKeyColors.TextPrimary
            )
        }
        Text(
            "${(session.similarity * 100).toInt()}%",
            color = if (session.authenticated) CardioKeyColors.NeonMint else CardioKeyColors.ElectricCoral,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp
        )
        Spacer(Modifier.width(8.dp))
        Icon(
            if (session.authenticated) Icons.Default.CheckCircle else Icons.Default.Cancel,
            null,
            tint = if (session.authenticated) CardioKeyColors.NeonMint else CardioKeyColors.ElectricCoral,
            modifier = Modifier.size(16.dp)
        )
    }
}
