package com.cardiokey.ui.theme

import androidx.compose.ui.graphics.Color

// CardioKey Futuristic Health-Tech Dark Theme
object CardioKeyColors {
    // Backgrounds
    val BackgroundInk = Color(0xFF060816)          // Deep Dark Ink
    val SurfaceNavy = Color(0xFF14182D)            // Dark Navy (opaque base for cards)
    val SurfaceNavyTranslucent = Color(0xEB14182D) // ~92% opacity equivalent

    // Accents
    val NeonMint = Color(0xFF00FFAE)               // Success / Authenticated
    val ElectricCoral = Color(0xFFFF4D6D)          // Denied / Errors
    val PurpleStart = Color(0xFFBB3CFF)            // Gradient start
    val PurpleEnd = Color(0xFF7C3AED)              // Gradient end

    // Typography
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF9CA3AF)
    val TextMuted = Color(0xFF6B7280)

    // Semantic
    val CardBorder = Color(0xFF1E2347)
    val DividerLine = Color(0xFF1A1F3A)
    val InputBackground = Color(0xFF0D1022)
    val ChipSelected = Color(0x33BB3CFF)           // 20% purple tint for selected chips

    // Health metric specific
    val HeartRateColor = Color(0xFFFF4D6D)
    val HrvColor = Color(0xFF00FFAE)
    val RespiratoryColor = Color(0xFF4DA8FF)
    val SpO2Color = Color(0xFFFFD166)
    val StressColor = Color(0xFFBB3CFF)
    val AfibColor = Color(0xFFFF6B6B)

    // Status
    val AccessGranted = Color(0xFF00FFAE)
    val AccessDenied = Color(0xFFFF4D6D)
    val StatusAmber = Color(0xFFFFB703)
}

// Material3 color scheme mappings
val md_theme_dark_primary = CardioKeyColors.NeonMint
val md_theme_dark_onPrimary = Color(0xFF003822)
val md_theme_dark_primaryContainer = CardioKeyColors.PurpleEnd
val md_theme_dark_onPrimaryContainer = Color(0xFFEADDFF)
val md_theme_dark_secondary = CardioKeyColors.PurpleStart
val md_theme_dark_onSecondary = Color(0xFF1A0036)
val md_theme_dark_background = CardioKeyColors.BackgroundInk
val md_theme_dark_onBackground = Color(0xFFFFFFFF)
val md_theme_dark_surface = CardioKeyColors.SurfaceNavy
val md_theme_dark_onSurface = Color(0xFFFFFFFF)
val md_theme_dark_surfaceVariant = Color(0xFF0D1022)
val md_theme_dark_onSurfaceVariant = CardioKeyColors.TextSecondary
val md_theme_dark_error = CardioKeyColors.ElectricCoral
val md_theme_dark_onError = Color(0xFF690005)
val md_theme_dark_outline = CardioKeyColors.CardBorder
