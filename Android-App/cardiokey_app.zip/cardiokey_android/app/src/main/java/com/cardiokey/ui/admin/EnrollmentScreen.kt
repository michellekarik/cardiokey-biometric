package com.cardiokey.ui.admin

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.UserProfile
import com.cardiokey.ui.components.CKCard
import com.cardiokey.ui.components.CKErrorText
import com.cardiokey.ui.components.CKLoadingRow
import com.cardiokey.ui.components.GradientButton
import com.cardiokey.ui.theme.CardioKeyColors
import com.cardiokey.viewmodel.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnrollmentScreen(
    enrollVm: EnrollViewModel,
    authVm: AuthViewModel,
    userVm: UserManagementViewModel
) {
    val enrollState by enrollVm.state.collectAsState()
    val authState by authVm.state.collectAsState()
    val users by userVm.users.collectAsState()
    val isLoadingUsers by userVm.isLoadingUsers.collectAsState()

    var selectedUser by remember { mutableStateOf<UserProfile?>(null) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { userVm.refreshUsers() }

    // If users list refreshes and selectedUser was set, update it from fresh data
    LaunchedEffect(users) {
        selectedUser?.let { curr ->
            users.find { it.userId == curr.userId }?.let { selectedUser = it }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CardioKeyColors.BackgroundInk)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PersonAdd, null, tint = CardioKeyColors.PurpleStart, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Biometric Scan Station", style = MaterialTheme.typography.headlineSmall)
                Text("Enrollment (5 min) & Quick Auth (15 sec)", style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextSecondary)
            }
        }

        Spacer(Modifier.height(24.dp))

        // User Selector Card
        CKCard(modifier = Modifier.fillMaxWidth()) {
            Text("Select User", fontWeight = FontWeight.SemiBold, color = CardioKeyColors.TextPrimary)
            Spacer(Modifier.height(12.dp))

            if (isLoadingUsers) {
                CKLoadingRow("Loading users from Supabase…")
            } else {
                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedUser?.let { "${it.firstName} ${it.lastName} (${it.email})" } ?: "Select a registered user…",
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(dropdownExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CardioKeyColors.PurpleStart,
                            unfocusedBorderColor = CardioKeyColors.CardBorder,
                            focusedTextColor = CardioKeyColors.TextPrimary,
                            unfocusedTextColor = CardioKeyColors.TextPrimary
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier.background(CardioKeyColors.SurfaceNavy)
                    ) {
                        if (users.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No users registered yet. Add one in Users tab.", color = CardioKeyColors.TextMuted) },
                                onClick = { dropdownExpanded = false }
                            )
                        } else {
                            users.forEach { user ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    "${user.firstName} ${user.lastName}",
                                                    color = CardioKeyColors.TextPrimary,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                if (user.isVerified) {
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("✓ Enrolled", color = CardioKeyColors.NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                            Text(user.email, color = CardioKeyColors.TextMuted, fontSize = 11.sp)
                                        }
                                    },
                                    onClick = {
                                        selectedUser = user
                                        dropdownExpanded = false
                                        enrollVm.reset()
                                        authVm.reset()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Selected user profile badge
            selectedUser?.let { user ->
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardioKeyColors.SurfaceNavy.copy(alpha = 0.6f))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${user.firstName} ${user.lastName}", fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary)
                        Text("Age: ${user.age}  •  Sex: ${user.sex}", fontSize = 12.sp, color = CardioKeyColors.TextSecondary)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (user.isVerified) CardioKeyColors.NeonMint.copy(alpha = 0.15f)
                                else CardioKeyColors.StatusAmber.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (user.isVerified) "ENROLLED" else "NOT ENROLLED",
                            color = if (user.isVerified) CardioKeyColors.NeonMint else CardioKeyColors.StatusAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Scan Controller (Active State or Action Buttons)
        val isAuthActive = authState !is AuthUiState.Idle
        val isEnrollActive = enrollState !is EnrollUiState.Idle

        if (!isAuthActive && !isEnrollActive) {
            // Idle State: Show both Enroll and Auth options for the selected user
            CKCard(modifier = Modifier.fillMaxWidth()) {
                Text("Select Action", fontWeight = FontWeight.SemiBold, color = CardioKeyColors.TextPrimary)
                Spacer(Modifier.height(14.dp))

                GradientButton(
                    text = "Start Biometric Enrollment (5 Mins)",
                    onClick = { selectedUser?.let { enrollVm.startEnrollment(it.userId) } },
                    enabled = selectedUser != null,
                    icon = Icons.Default.PlayArrow,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                GradientButton(
                    text = "Start Biometric Authentication (15 Secs)",
                    onClick = { selectedUser?.let { authVm.startAuthScan(it.userId) } },
                    enabled = selectedUser != null,
                    icon = Icons.Default.Fingerprint,
                    modifier = Modifier.fillMaxWidth()
                )

                if (selectedUser == null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Please select a user above to begin enrollment or authentication.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CardioKeyColors.TextMuted
                    )
                }
            }
        } else if (isEnrollActive) {
            // Enrollment flow active
            AnimatedContent(
                targetState = enrollState,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "enrollment_flow"
            ) { currentState ->
                when (currentState) {
                    is EnrollUiState.Idle -> { /* handled above */ }
                    is EnrollUiState.Preparing -> {
                        EnrollStateCard("Preparing…", "Initializing enrollment session with ESP32", Icons.Default.Settings,
                            CardioKeyColors.PurpleStart)
                    }
                    is EnrollUiState.CheckingSensors -> {
                        EnrollStateCard("Checking Sensors…", "Verifying ECG + PPG sensor readiness",
                            Icons.Default.MonitorHeart, CardioKeyColors.StatusAmber)
                    }
                    is EnrollUiState.Recording -> {
                        EnrollRecordingCard(
                            sessionId = currentState.sessionId,
                            totalSeconds = currentState.totalSeconds
                        )
                    }
                    is EnrollUiState.Uploading -> {
                        EnrollStateCard("Uploading to S3…", "Pushing 5-minute recording to cloud storage",
                            Icons.Default.CloudUpload, CardioKeyColors.NeonMint)
                    }
                    is EnrollUiState.Processing -> {
                        EnrollStateCard("Processing…", "Registering session in Supabase",
                            Icons.Default.AutoAwesome, CardioKeyColors.PurpleStart)
                    }
                    is EnrollUiState.Complete -> {
                        Column {
                            CKCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, null, tint = CardioKeyColors.NeonMint,
                                        modifier = Modifier.size(32.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("Enrollment Uploaded Successfully!", fontWeight = FontWeight.Bold,
                                            color = CardioKeyColors.NeonMint)
                                        Text("5-minute biometric data safely stored in S3 and linked to ${selectedUser?.firstName ?: "user"} in Supabase.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CardioKeyColors.TextSecondary)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            GradientButton(
                                text = "Done / Next Scan",
                                onClick = {
                                    enrollVm.reset()
                                    userVm.refreshUsers()
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    is EnrollUiState.RetakeRequired -> {
                        Column {
                            CKCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, null, tint = CardioKeyColors.ElectricCoral,
                                        modifier = Modifier.size(32.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("Retake Required", fontWeight = FontWeight.Bold,
                                            color = CardioKeyColors.ElectricCoral)
                                        Text(currentState.reason, style = MaterialTheme.typography.bodySmall,
                                            color = CardioKeyColors.TextSecondary)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            GradientButton(text = "Try Again", onClick = { enrollVm.reset() },
                                modifier = Modifier.fillMaxWidth())
                        }
                    }
                    is EnrollUiState.Error -> {
                        Column {
                            CKErrorText(currentState.message)
                            Spacer(Modifier.height(12.dp))
                            GradientButton(text = "Dismiss", onClick = { enrollVm.reset() },
                                modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        } else if (isAuthActive) {
            // Auth flow active
            AnimatedContent(
                targetState = authState,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "auth_flow"
            ) { currentState ->
                when (currentState) {
                    is AuthUiState.Idle -> { /* handled above */ }
                    is AuthUiState.Starting -> {
                        EnrollStateCard("Starting…", "Sending start trigger to ESP32", Icons.Default.Settings,
                            CardioKeyColors.PurpleStart)
                    }
                    is AuthUiState.Recording -> {
                        AuthRecordingCardInline(
                            sessionId = currentState.sessionId,
                            totalSeconds = currentState.totalSeconds
                        )
                    }
                    is AuthUiState.Uploading -> {
                        EnrollStateCard("Uploading…", "Sending 15-second recording to S3",
                            Icons.Default.CloudUpload, CardioKeyColors.NeonMint)
                    }
                    is AuthUiState.Processing -> {
                        EnrollStateCard("Processing…", "Verifying biometric match in backend",
                            Icons.Default.AutoAwesome, CardioKeyColors.PurpleStart)
                    }
                    is AuthUiState.Result -> {
                        Column {
                            AuthScanResultCard(session = currentState.session, expectedUser = selectedUser)
                            Spacer(Modifier.height(12.dp))
                            GradientButton(
                                text = "Done / Next Scan",
                                onClick = { authVm.reset() },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    is AuthUiState.Error -> {
                        Column {
                            CKErrorText(currentState.message)
                            Spacer(Modifier.height(12.dp))
                            GradientButton(text = "Dismiss", onClick = { authVm.reset() },
                                modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EnrollStateCard(
    title: String,
    body: String,
    icon: ImageVector,
    color: Color
) {
    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                strokeWidth = 3.dp,
                color = color
            )
            Spacer(Modifier.width(12.dp))
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, color = color)
                Text(body, style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
            }
        }
    }
}

@Composable
private fun EnrollRecordingCard(sessionId: String, totalSeconds: Int) {
    var secondsRemaining by remember(sessionId) { mutableIntStateOf(totalSeconds) }
    LaunchedEffect(sessionId) {
        while (secondsRemaining > 0) { delay(1000L); secondsRemaining-- }
    }
    val minutes = secondsRemaining / 60
    val seconds = secondsRemaining % 60
    val progress = if (totalSeconds > 0) secondsRemaining.toFloat() / totalSeconds.toFloat() else 0f

    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardioKeyColors.ElectricCoral.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Favorite, null, tint = CardioKeyColors.ElectricCoral,
                    modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Enrollment Recording (5 Mins)", fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary)
                Text("ECG + PPG capture (session: ${sessionId.take(8)}…)",
                    style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextMuted)
            }
        }
        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Time Remaining", color = CardioKeyColors.TextSecondary)
            Text(
                text = "%02d:%02d".format(minutes, seconds),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = CardioKeyColors.NeonMint
            )
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = CardioKeyColors.NeonMint,
            trackColor = CardioKeyColors.CardBorder
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Hold fingers firmly on sensor plates. ESP32 OLED mirrors this countdown.",
            style = MaterialTheme.typography.bodySmall,
            color = CardioKeyColors.TextMuted
        )
    }
}

@Composable
private fun AuthRecordingCardInline(sessionId: String, totalSeconds: Int) {
    var secondsRemaining by remember(sessionId) { mutableIntStateOf(totalSeconds) }
    LaunchedEffect(sessionId) {
        while (secondsRemaining > 0) { delay(1000L); secondsRemaining-- }
    }
    val progress = if (totalSeconds > 0) secondsRemaining.toFloat() / totalSeconds.toFloat() else 0f

    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CardioKeyColors.NeonMint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Fingerprint, null, tint = CardioKeyColors.NeonMint,
                    modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Authentication Scan (15 Secs)", fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary)
                Text("Scanning biometric signature…",
                    style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextMuted)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Seconds Remaining", color = CardioKeyColors.TextSecondary)
            Text(
                text = "${secondsRemaining}s",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = CardioKeyColors.NeonMint
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = CardioKeyColors.NeonMint,
            trackColor = CardioKeyColors.CardBorder
        )
    }
}

@Composable
private fun AuthScanResultCard(session: AuthSessionResponse, expectedUser: UserProfile?) {
    val isMatch = session.authenticated
    val matchColor = if (isMatch) CardioKeyColors.NeonMint else CardioKeyColors.ElectricCoral

    CKCard(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (isMatch) Icons.Default.CheckCircle else Icons.Default.Cancel,
                null,
                tint = matchColor,
                modifier = Modifier.size(36.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isMatch) "AUTHENTICATION SUCCESSFUL" else "AUTHENTICATION FAILED",
                    fontWeight = FontWeight.Bold,
                    color = matchColor
                )
                Text(
                    text = session.predictedUser?.let { "Identified as: $it" } ?: (expectedUser?.let { "User: ${it.firstName} ${it.lastName}" } ?: "Biometric scan processed"),
                    style = MaterialTheme.typography.bodySmall,
                    color = CardioKeyColors.TextPrimary
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = CardioKeyColors.CardBorder)
        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Similarity", style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
                Text("%.1f%%".format(session.similarity * 100), fontWeight = FontWeight.Bold, color = matchColor, fontSize = 18.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Threshold", style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
                Text("%.1f%%".format(session.threshold * 100), fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary, fontSize = 18.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Margin", style = MaterialTheme.typography.bodySmall, color = CardioKeyColors.TextSecondary)
                Text("%.3f".format(session.margin), fontWeight = FontWeight.Bold, color = CardioKeyColors.TextPrimary, fontSize = 18.sp)
            }
        }
    }
}
