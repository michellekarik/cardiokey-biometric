package com.cardiokey.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cardiokey.data.AppPreferences
import com.cardiokey.data.models.AdminSystemStats
import com.cardiokey.data.models.AuthSessionResponse
import com.cardiokey.data.models.UserProfile
import com.cardiokey.data.repository.FlaskRepository
import com.cardiokey.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AdminDashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = AppPreferences(application)
    private var repo: FlaskRepository? = null

    private val _stats = MutableStateFlow<AdminSystemStats?>(null)
    val stats: StateFlow<AdminSystemStats?> = _stats.asStateFlow()

    private val _users = MutableStateFlow<List<UserProfile>>(emptyList())
    val users: StateFlow<List<UserProfile>> = _users.asStateFlow()

    private val _userHistories = MutableStateFlow<Map<String, List<AuthSessionResponse>>>(emptyMap())
    val userHistories: StateFlow<Map<String, List<AuthSessionResponse>>> = _userHistories.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private suspend fun getRepo(): FlaskRepository {
        return repo ?: run {
            val url = prefs.backendUrl.first()?.takeIf { it.isNotBlank() } ?: "https://your-backend-url.example.com/"
            FlaskRepository(NetworkModule.flaskApi(url)).also { repo = it }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            val r = getRepo()
            r.getAdminStats()
                .onSuccess { _stats.value = it }
                .onFailure { _error.value = it.message }
            r.getAllUsers()
                .onSuccess { _users.value = it }
                .onFailure { /* keep old list */ }
            _isLoading.value = false
        }
    }

    fun loadUserHistory(userId: String) {
        if (_userHistories.value.containsKey(userId)) return
        viewModelScope.launch {
            getRepo().getUserHistory(userId)
                .onSuccess { history ->
                    _userHistories.value = _userHistories.value + (userId to history)
                }
        }
    }
}
