# CardioKey Android + EC2 integration fixes

This is a source-level integration repair based on the current Android project,
the older hardware-working Android project, the supplied Flask `app.py`, the
pasted ESP32 firmware and the supplied Supabase schema.

## What changed

### Android
- User directory starts empty and loads from `GET /api/v1/users/list`.
- Removed the fabricated local-user success path. If Supabase fails, the app
  shows an error instead of generating a fake `usr_...` ID.
- Removed fake sample history and fake customer verification fallbacks.
- Backend default is `https://your-backend-url.example.com/` (API root).
- Wi-Fi provisioning no longer stores the ESP32 presign endpoint as the
  Android Flask base URL.
- Enrollment and authentication start commands now go directly to the ESP32:
  - `POST http://<ESP32-IP>/enroll/start` with `{ "user_id": "<Supabase UUID>" }`
  - `POST http://<ESP32-IP>/auth/start`
- Android polls the ESP32's `/session/{id}/status` route for real recording and
  upload states. It no longer assumes a 301-second/16-second delay means the
  hardware has completed.
- After ESP32 reports `upload_ok` or `upload_failed`, Android reports that
  state to Flask so Supabase `auth_sessions` can be updated.
- Authentication upload success is NOT displayed as a biometric match.
  The app waits for a real backend processing verdict.

### Flask
- Removed literal AWS and Supabase credentials.
- Uses the EC2 instance role / boto3 credential chain and environment variables.
- Expects `SUPABASE_URL` to be the project root, not `/rest/v1/`.
- User-create and user-list endpoints use Supabase and return real errors.
- Presign endpoint requires the ESP32's active `session_id`, session `type`,
  and enrollment `user_id`; it writes the same ID into `auth_sessions`.
- Added device-status, session-status, user-history and ground-truth endpoints.
- Removed fabricated accuracy values.

### ESP32
- Included the exact firmware patch needed to send the existing ESP32 session ID
  and user UUID to the Flask presign route.
- Included a guard against returning HTTP 200 if the recording file could not
  be opened.

## Required firmware patch

Open `firmware/ESP32_REQUIRED_PATCH.txt` and apply all numbered changes to the
currently flashed `.ino`. Recompile and flash the ESP32. This patch is essential:
without the same `session_id` being sent to `/presign/auth`, the S3 object and
Supabase session row can refer to different sessions.

The ESP32 continues to own sensor sampling, 301-second enrollment capture,
16-second authentication capture and S3 upload.

## Backend deployment

Follow `backend/DEPLOYMENT.md`. Rotate the credentials exposed in the previously
uploaded Flask file before deployment. Configure:

- `SUPABASE_URL=https://<project-ref>.supabase.co`
- `SUPABASE_SERVICE_ROLE_KEY=<rotated service role key>`
- `S3_BUCKET=cardiokey-biometric-dataset`
- `AWS_REGION=ap-south-1`

Use an EC2 IAM role for S3 instead of long-lived AWS keys where possible.

## Supabase migration

The supplied `auth_sessions` schema does not include `predicted_user_id`, while
the Android response model supports it. Apply this optional migration if the
processing worker will persist the matched user's UUID:

```sql
ALTER TABLE public.auth_sessions
ADD COLUMN IF NOT EXISTS predicted_user_id UUID
REFERENCES public.users(id);
```

No biometric threshold, model, embedding, or enrollment acceptance rule was
changed.

## Install / run

1. Open this folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Set the Android SDK path locally if prompted (do not commit `local.properties`).
4. Build > Make Project.
5. Install the newly built debug APK on the phone.

A Gradle compile was attempted in the packaging environment but could not run
because Gradle 8.12 was not cached and external downloads are disabled there.
Therefore this package is source-patched but the new APK has NOT been built or
device-tested here.

## Test sequence

1. Ensure EC2 Flask `/health` returns `status: ok` and
   `supabase_configured: true`.
2. In Android Setup, save the Flask **base URL**:
   `https://your-backend-url.example.com/`
3. Join phone to `CARDIOKEY-ESP32`; run setup check and provision the home Wi-Fi.
4. Rejoin the phone to the same home Wi-Fi as the ESP32.
5. Enter the ESP32 IP shown on its OLED and confirm `/status`.
6. Create a test user. Confirm the row exists in Supabase `public.users`.
7. Close and reopen the app. Refresh Users. The same user must load from Supabase.
8. Select that user in Enroll. Start enrollment. Verify ESP32 serial output,
   S3 object, and matching `auth_sessions.session_id` + `user_id`.
9. Run authentication. Verify the 15-second recording and upload. Do not call
   it a successful match until the backend processing worker writes a real
   verdict to `auth_sessions`.

## Important limitations / remaining integration dependencies

- The supplied Flask file is a gateway and user/session API. It does not itself
  contain the CNN-LSTM embedding pipeline or a worker that processes S3 uploads.
  Your existing EC2 processing worker must continue to consume the correct S3
  prefixes and update `auth_sessions` with a real result.
- Android reports upload state to Flask after it observes the ESP32 terminal
  state. If the app is force-stopped during upload, this status callback will
  not occur. The S3 object and presign-created row may still exist; a future
  firmware-to-Flask callback or S3 event worker is the robust production fix.
- The uploaded `public.users` table has no email-verification column or
  verification workflow. The Android admin onboarding message was changed so it
  no longer falsely claims an email verification link was sent.
- The uploaded Android app's local admin PIN is not server-side authorization.
  Do not expose write endpoints publicly for production without adding real
  server-side admin authentication.
- The TLS CertPathValidatorException must be fixed on Caddy / the certificate
  chain. Do not disable certificate validation in Android.
