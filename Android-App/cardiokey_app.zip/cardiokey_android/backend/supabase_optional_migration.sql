-- Optional: the Android AuthSessionResponse supports a predicted user UUID.
-- Apply only if your processing worker will populate this field.
ALTER TABLE public.auth_sessions
ADD COLUMN IF NOT EXISTS predicted_user_id UUID
REFERENCES public.users(id);
