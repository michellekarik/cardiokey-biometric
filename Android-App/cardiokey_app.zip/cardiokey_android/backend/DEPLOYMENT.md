CARDIOKEY BACKEND DEPLOYMENT
============================

A. Rotate credentials FIRST
----------------------------
The app.py uploaded for review contained literal AWS access credentials and a
Supabase service-role secret. Treat both as compromised:
1. Disable/delete the exposed AWS access key and create a new one if you are not
   using an EC2 instance role.
2. Rotate the Supabase service-role secret in Supabase.
3. Never paste the new values into source code, Android, Git or chat.

B. EC2 environment
------------------
Preferred AWS setup: attach an IAM role to the EC2 instance with only the
permissions needed for the CardioKey bucket (s3:PutObject, s3:GetObject and any
required list permissions). boto3 will use the instance role automatically.

Set these variables in the systemd service EnvironmentFile (or secure service
environment), using the Supabase project root URL, NOT /rest/v1/:

SUPABASE_URL=https://<project-ref>.supabase.co
SUPABASE_SERVICE_ROLE_KEY=<ROTATED_SERVICE_ROLE_SECRET>
S3_BUCKET=cardiokey-biometric-dataset
AWS_REGION=ap-south-1
PORT=5050

Do not place the service-role key in the Android application.

C. Install / deploy
-------------------
Activate the same Python virtual environment used by the running Flask service:

pip install Flask flask-cors boto3 supabase

Back up the deployed app.py, copy this package's backend/app.py into the
existing application directory, then restart the existing systemd service:

sudo cp app.py app.py.before-cardiokey-fix
sudo systemctl restart cardiokey
sudo systemctl status cardiokey --no-pager
sudo journalctl -u cardiokey -n 100 --no-pager

Use your actual service name if it is not "cardiokey".

D. Smoke tests
--------------
1. Health:
   curl -i https://your-backend-url.example.com/health

2. User list:
   curl -i https://your-backend-url.example.com/api/v1/users/list

3. Create one test user:
   curl -i -X POST https://your-backend-url.example.com/api/v1/users/create \
     -H 'Content-Type: application/json' \
     -d '{"first_name":"Test","last_name":"CardioKey","email":"test-cardio@example.com","age":25,"sex":"Other"}'

4. Confirm the user exists:
   curl -i https://your-backend-url.example.com/api/v1/users/list

5. Presign test requires a real Supabase UUID from users.id:
   curl -i 'https://your-backend-url.example.com/presign/auth?session_id=smoke_test_001&type=auth'

E. Important session contract
-----------------------------
Android POSTs /enroll/start and /auth/start directly to the ESP32.
ESP32 creates its own session_id and records the sensor data.
ESP32 then calls Flask /presign/auth with that SAME session_id, type and user_id.
Flask upserts public.auth_sessions and returns a presigned S3 PUT URL.
ESP32 uploads the CSV to S3.
Android polls ESP32 /session/{session_id}/status. Once it sees upload_ok,
Android POSTs /api/v1/sessions/{session_id}/device-status so Supabase reflects
the upload outcome.

A background processing worker must still consume the S3 object, generate the
embedding / authentication result and update auth_sessions. This app.py does
not fabricate a biometric verdict or mark an enrollment template ACTIVE.
